import { useEffect, useState, useCallback, useRef } from 'react';
import { useStore } from '@/store/useStore';
import { getTheme } from '@/lib/themes';
import Topbar from '@/components/Topbar';
import Sidebar from '@/components/Sidebar';
import InfoPanel from '@/components/InfoPanel';
import Terminal from '@/components/Terminal';
import BootSequence from '@/components/BootSequence';
import NanoEditor from '@/components/NanoEditor';
import CMatrix from '@/components/CMatrix';
import CustomCursor from '@/components/CustomCursor';
import type { ThemeName } from '@/types';

function App() {
  const bootComplete = useStore((s) => s.bootComplete);
  const setBootComplete = useStore((s) => s.setBootComplete);
  const theme = useStore((s) => s.theme);
  const sidebarVisible = useStore((s) => s.sidebarVisible);
  const infoPanelVisible = useStore((s) => s.infoPanelVisible);
  const [nanoOpen, setNanoOpen] = useState(false);
  const [nanoFile, setNanoFile] = useState('');
  const [cmatrixActive, setCmatrixActive] = useState(false);
  const [zenMode, setZenMode] = useState(false);

  const currentTheme = getTheme(theme);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!bootComplete) setBootComplete(true);
    }, 6000);
    return () => clearTimeout(timer);
  }, [bootComplete, setBootComplete]);

  // Theme CSS variables
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--bg-color', currentTheme.colors.background);
    root.style.setProperty('--surface-color', currentTheme.colors.surface);
    root.style.setProperty('--surface-glass', currentTheme.colors.surfaceGlass);
    root.style.setProperty('--text-primary', currentTheme.colors.textPrimary);
    root.style.setProperty('--text-secondary', currentTheme.colors.textSecondary);
    root.style.setProperty('--text-muted', currentTheme.colors.textMuted);
    root.style.setProperty('--accent-primary', currentTheme.colors.accentPrimary);
    root.style.setProperty('--accent-secondary', currentTheme.colors.accentSecondary);
    root.style.setProperty('--accent-warning', currentTheme.colors.accentWarning);
    root.style.setProperty('--accent-error', currentTheme.colors.accentError);
    root.style.setProperty('--accent-info', currentTheme.colors.accentInfo);
  }, [currentTheme]);

  const handleNanoOpen = useCallback((filename: string) => {
    setNanoFile(filename);
    setNanoOpen(true);
  }, []);

  const handleNanoClose = useCallback(() => {
    setNanoOpen(false);
  }, []);

  const handleCMatrix = useCallback((active: boolean) => {
    setCmatrixActive(active);
  }, []);

  const handleZenMode = useCallback((active: boolean) => {
    setZenMode(active);
  }, []);

  if (!bootComplete) {
    return <BootSequence theme={theme as ThemeName} />;
  }

  if (cmatrixActive) {
    return (
      <div className="fixed inset-0" style={{ background: currentTheme.colors.background }}>
        <CMatrix onExit={() => setCmatrixActive(false)} theme={currentTheme} />
      </div>
    );
  }

  return (
    <div
      className="h-screen w-screen flex flex-col overflow-hidden transition-colors duration-400"
      style={{ background: currentTheme.colors.background }}
    >
      <CustomCursor />
      {!zenMode && <Topbar onZenMode={handleZenMode} />}
      <div className="flex flex-1 overflow-hidden">
        {!zenMode && sidebarVisible && <Sidebar />}
        <main className="flex-1 flex flex-col min-w-0 relative">
          <Terminal
            onNanoOpen={handleNanoOpen}
            onCMatrix={handleCMatrix}
            onZenMode={handleZenMode}
            zenMode={zenMode}
          />
        </main>
        {!zenMode && infoPanelVisible && <InfoPanel />}
      </div>
      {nanoOpen && <NanoEditor filename={nanoFile} onClose={handleNanoClose} />}
    </div>
  );
}

export default App;
