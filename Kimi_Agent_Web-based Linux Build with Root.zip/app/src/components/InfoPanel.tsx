import { useState, useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { getTheme } from '@/lib/themes';
import { Activity, Cpu, HardDrive, Wifi, Users, Clock, Shield, FileStack } from 'lucide-react';

export default function InfoPanel() {
  const theme = useStore((s) => s.theme);
  const processes = useStore((s) => s.processes);
  const currentUser = useStore((s) => s.currentUser);
  const currentDirectory = useStore((s) => s.currentDirectory);
  const groups = useStore((s) => s.groups);
  const filesystem = useStore((s) => s.filesystem);
  const currentTheme = getTheme(theme);

  const [rx, setRx] = useState(98765432);
  const [tx, setTx] = useState(45678901);

  useEffect(() => {
    const interval = setInterval(() => {
      setRx(prev => prev + Math.floor(Math.random() * 1000));
      setTx(prev => prev + Math.floor(Math.random() * 500));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Get current dir info
  const findNode = (fs: typeof filesystem, path: string) => {
    if (path === '/') return fs;
    const parts = path.split('/').filter(Boolean);
    let current = fs;
    for (const part of parts) {
      if (current.type !== 'directory' || !current.children) return null;
      current = current.children[part];
      if (!current) return null;
    }
    return current;
  };

  const currentNode = findNode(filesystem, currentDirectory);
  const fileCount = currentNode?.type === 'directory' && currentNode.children
    ? Object.values(currentNode.children).filter(c => c.type === 'file').length
    : 0;
  const dirCount = currentNode?.type === 'directory' && currentNode.children
    ? Object.values(currentNode.children).filter(c => c.type === 'directory').length
    : 0;

  const userGroups = groups.filter(g => g.members.includes(currentUser)).map(g => g.name);

  const totalMem = 16384;
  const usedMem = 8192;
  const memPercent = (usedMem / totalMem) * 100;

  // Sort processes by CPU
  const sortedProcesses = [...processes].sort((a, b) => b.cpu - a.cpu);

  const SectionHeader = ({ icon, label }: { icon: React.ReactNode; label: string }) => (
    <div className="flex items-center gap-2 px-4 py-2.5">
      {icon}
      <span
        className="text-[11px] font-medium uppercase tracking-wider"
        style={{
          color: currentTheme.colors.textSecondary,
          fontFamily: 'PP Neue Montreal, sans-serif',
          letterSpacing: '0.05em',
        }}
      >
        {label}
      </span>
    </div>
  );

  const InfoRow = ({ label, value, color }: { label: string; value: string; color?: string }) => (
    <div className="flex items-center justify-between px-4 py-1">
      <span className="text-[11px]" style={{ color: currentTheme.colors.textMuted }}>{label}</span>
      <span className="text-[11px] font-mono" style={{ color: color || currentTheme.colors.textSecondary }}>{value}</span>
    </div>
  );

  return (
    <aside
      className="flex-shrink-0 flex flex-col overflow-hidden select-none"
      style={{
        width: 300,
        background: currentTheme.colors.surfaceGlass,
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        borderLeft: '1px solid rgba(255, 255, 255, 0.08)',
        boxShadow: 'inset 0 0 0 1px rgba(255, 255, 255, 0.05), 0 8px 32px rgba(0, 0, 0, 0.3)',
      }}
    >
      {/* System Status */}
      <SectionHeader icon={<Activity size={12} style={{ color: currentTheme.colors.accentPrimary }} />} label="System Status" />
      <div style={{ height: 1, background: 'rgba(255, 255, 255, 0.06)', margin: '0 16px' }} />
      <InfoRow label="Uptime" value={`${Math.floor(328472 / 86400)}d ${Math.floor((328472 % 86400) / 3600)}h ${Math.floor((328472 % 3600) / 60)}m`} />
      <div className="px-4 py-1.5">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px]" style={{ color: currentTheme.colors.textMuted }}>Load avg</span>
          <span className="text-[10px] font-mono" style={{ color: currentTheme.colors.accentPrimary }}>0.42 0.38 0.35</span>
        </div>
        <div className="flex gap-0.5 h-1">
          {[0.42, 0.38, 0.35].map((load, i) => (
            <div
              key={i}
              className="flex-1 rounded-full"
              style={{
                background: currentTheme.colors.accentPrimary,
                opacity: 0.3 + load * 0.7,
              }}
            />
          ))}
        </div>
      </div>
      <div className="px-4 py-1.5">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px]" style={{ color: currentTheme.colors.textMuted }}>Memory</span>
          <span className="text-[10px] font-mono" style={{ color: currentTheme.colors.accentPrimary }}>{usedMem}M / {totalMem}M</span>
        </div>
        <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255, 255, 255, 0.05)' }}>
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${memPercent}%`,
              background: `linear-gradient(90deg, ${currentTheme.colors.accentPrimary}, ${currentTheme.colors.accentError})`,
            }}
          />
        </div>
      </div>

      {/* Processes */}
      <div className="mt-2" style={{ height: 1, background: 'rgba(255, 255, 255, 0.06)' }} />
      <SectionHeader icon={<Cpu size={12} style={{ color: currentTheme.colors.accentSecondary }} />} label="Active Processes" />
      <div style={{ height: 1, background: 'rgba(255, 255, 255, 0.06)', margin: '0 16px' }} />
      <div className="overflow-y-auto flex-1" style={{ maxHeight: 200, scrollbarWidth: 'thin', scrollbarColor: 'rgba(255,255,255,0.08) transparent' }}>
        <div className="grid grid-cols-4 gap-1 px-4 py-1.5 text-[9px] uppercase tracking-wider" style={{ color: currentTheme.colors.textMuted }}>
          <span>PID</span>
          <span>Name</span>
          <span className="text-right">CPU</span>
          <span className="text-right">MEM</span>
        </div>
        {sortedProcesses.map((proc) => (
          <div
            key={proc.pid}
            className="grid grid-cols-4 gap-1 px-4 py-0.5 text-[10px] font-mono transition-colors duration-100 hover:bg-white/[0.03] rounded-sm"
          >
            <span style={{ color: currentTheme.colors.textSecondary }}>{proc.pid}</span>
            <span className="truncate" style={{ color: currentTheme.colors.textPrimary }}>{proc.command}</span>
            <span className="text-right" style={{ color: currentTheme.colors.accentPrimary }}>{proc.cpu.toFixed(1)}</span>
            <span className="text-right" style={{ color: currentTheme.colors.accentSecondary }}>{proc.mem.toFixed(0)}</span>
          </div>
        ))}
      </div>

      {/* Context */}
      <div className="mt-2" style={{ height: 1, background: 'rgba(255, 255, 255, 0.06)' }} />
      <SectionHeader icon={<Users size={12} style={{ color: currentTheme.colors.accentInfo }} />} label="Context" />
      <div style={{ height: 1, background: 'rgba(255, 255, 255, 0.06)', margin: '0 16px' }} />
      <InfoRow label="User" value={currentUser} color={currentUser === 'root' ? currentTheme.colors.accentError : currentTheme.colors.accentPrimary} />
      <InfoRow label="Groups" value={userGroups.join(', ')} />
      <InfoRow label="Directory" value={currentDirectory.length > 20 ? '...' + currentDirectory.slice(-20) : currentDirectory} color={currentTheme.colors.accentSecondary} />
      <div className="flex items-center justify-between px-4 py-1">
        <span className="text-[11px]" style={{ color: currentTheme.colors.textMuted }}>Contents</span>
        <span className="text-[11px] font-mono" style={{ color: currentTheme.colors.textSecondary }}>{fileCount} files, {dirCount} dirs</span>
      </div>

      {/* Network */}
      <div className="mt-2" style={{ height: 1, background: 'rgba(255, 255, 255, 0.06)' }} />
      <SectionHeader icon={<Wifi size={12} style={{ color: '#00E5A0' }} />} label="Network" />
      <div style={{ height: 1, background: 'rgba(255, 255, 255, 0.06)', margin: '0 16px' }} />
      <InfoRow label="Interface" value="eth0" />
      <InfoRow label="IP" value="192.168.1.100" color={currentTheme.colors.accentInfo} />
      <div className="px-4 py-1">
        <div className="flex items-center gap-1.5">
          <span className="inline-block w-1.5 h-1.5 rounded-full" style={{ background: '#00E5A0' }} />
          <span className="text-[10px]" style={{ color: '#00E5A0' }}>connected</span>
        </div>
      </div>
      <div className="px-4 py-1">
        <div className="flex justify-between text-[9px] font-mono" style={{ color: currentTheme.colors.textMuted }}>
          <span>RX: {formatBytes(rx)}</span>
          <span>TX: {formatBytes(tx)}</span>
        </div>
      </div>
    </aside>
  );
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}K`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)}M`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)}G`;
}
