import { useState, useCallback } from 'react';
import { useStore } from '@/store/useStore';
import { getTheme } from '@/lib/themes';
import { findNode, resolvePath } from '@/lib/filesystem';
import { Folder, FolderOpen, FileText, ChevronRight, ChevronDown, Home, HardDrive, Settings, FileCode } from 'lucide-react';
import type { FileNode } from '@/types';

function getFileIcon(node: FileNode, color: string) {
  if (node.type === 'directory') return <Folder size={14} style={{ color }} />;
  if (node.type === 'symlink') return <FileCode size={14} style={{ color: '#38BDF8' }} />;
  if (node.name.endsWith('.sh')) return <FileCode size={14} style={{ color: '#00E5A0' }} />;
  if (node.name.endsWith('.conf') || node.name.endsWith('.cfg')) return <Settings size={14} style={{ color: '#FFB800' }} />;
  if (node.name.endsWith('.json')) return <FileCode size={14} style={{ color: '#38BDF8' }} />;
  return <FileText size={14} style={{ color: '#6B6B78' }} />;
}

function getFileColor(node: FileNode, theme: ReturnType<typeof getTheme>): string {
  if (node.type === 'directory') return theme.colors.accentSecondary;
  if (node.type === 'symlink') return '#38BDF8';
  if (node.name.endsWith('.sh')) return theme.colors.accentPrimary;
  if (node.name.endsWith('.conf') || node.name.endsWith('.cfg')) return theme.colors.accentWarning;
  if (node.name.endsWith('.txt') || node.name.endsWith('.md') || node.name.endsWith('.log')) return theme.colors.textPrimary;
  if (node.name.endsWith('.json')) return theme.colors.accentInfo;
  return theme.colors.textSecondary;
}

interface TreeItemProps {
  node: FileNode;
  path: string;
  depth: number;
  currentDir: string;
  onNavigate: (path: string) => void;
}

function TreeItem({ node, path, depth, currentDir, onNavigate }: TreeItemProps) {
  const [expanded, setExpanded] = useState(depth < 1);
  const theme = useStore((s) => s.theme);
  const currentTheme = getTheme(theme);
  const isActive = currentDir === path;
  const hasChildren = node.type === 'directory' && node.children && Object.keys(node.children).length > 0;

  const handleClick = useCallback(() => {
    if (node.type === 'directory' && hasChildren) {
      setExpanded(!expanded);
    }
    onNavigate(path);
  }, [node.type, hasChildren, expanded, path, onNavigate]);

  return (
    <div>
      <div
        onClick={handleClick}
        className="flex items-center gap-1 py-0.5 px-2 rounded-md cursor-pointer transition-all duration-150"
        style={{
          paddingLeft: `${12 + depth * 16}px`,
          background: isActive ? 'rgba(123, 97, 255, 0.12)' : 'transparent',
          border: isActive ? '1px solid rgba(123, 97, 255, 0.25)' : '1px solid transparent',
        }}
        onMouseEnter={(e) => {
          if (!isActive) e.currentTarget.style.background = 'rgba(255, 255, 255, 0.03)';
        }}
        onMouseLeave={(e) => {
          if (!isActive) e.currentTarget.style.background = 'transparent';
        }}
      >
        {hasChildren ? (
          expanded ? (
            <ChevronDown size={10} style={{ color: currentTheme.colors.accentSecondary }} />
          ) : (
            <ChevronRight size={10} style={{ color: currentTheme.colors.accentSecondary }} />
          )
        ) : (
          <span className="w-[10px]" />
        )}
        {getFileIcon(node, getFileColor(node, currentTheme))}
        <span
          className="text-[12px] truncate"
          style={{
            color: getFileColor(node, currentTheme),
            fontFamily: 'IBM Plex Mono, monospace',
          }}
        >
          {node.name || '/'}
        </span>
      </div>
      {expanded && hasChildren && node.children && (
        <div>
          {Object.values(node.children)
            .sort((a, b) => {
              if (a.type === 'directory' && b.type !== 'directory') return -1;
              if (a.type !== 'directory' && b.type === 'directory') return 1;
              return a.name.localeCompare(b.name);
            })
            .map((child) => (
              <TreeItem
                key={child.name}
                node={child}
                path={path === '/' ? `/${child.name}` : `${path}/${child.name}`}
                depth={depth + 1}
                currentDir={currentDir}
                onNavigate={onNavigate}
              />
            ))}
        </div>
      )}
    </div>
  );
}

export default function Sidebar() {
  const theme = useStore((s) => s.theme);
  const filesystem = useStore((s) => s.filesystem);
  const currentDirectory = useStore((s) => s.currentDirectory);
  const setCurrentDirectory = useStore((s) => s.setCurrentDirectory);
  const currentTheme = getTheme(theme);

  const handleNavigate = useCallback((path: string) => {
    const node = findNode(filesystem, path);
    if (node && node.type === 'directory') {
      setCurrentDirectory(path);
    }
  }, [filesystem, setCurrentDirectory]);

  const quickLinks = [
    { label: '~', path: '/root', icon: <Home size={12} /> },
    { label: '/', path: '/', icon: <HardDrive size={12} /> },
    { label: '/etc', path: '/etc', icon: <Settings size={12} /> },
    { label: '/var/log', path: '/var/log', icon: <FileText size={12} /> },
    { label: '/usr/bin', path: '/usr/bin', icon: <FileCode size={12} /> },
  ];

  return (
    <aside
      className="flex-shrink-0 flex flex-col overflow-hidden select-none"
      style={{
        width: 260,
        background: currentTheme.colors.surfaceGlass,
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        borderRight: '1px solid rgba(255, 255, 255, 0.08)',
        boxShadow: 'inset 0 0 0 1px rgba(255, 255, 255, 0.05), 0 8px 32px rgba(0, 0, 0, 0.3)',
      }}
    >
      {/* Header */}
      <div
        className="px-5 py-3 flex items-center gap-2"
        style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.06)' }}
      >
        <FolderOpen size={14} style={{ color: currentTheme.colors.accentSecondary }} />
        <span
          className="text-[13px] font-medium uppercase tracking-wider"
          style={{
            color: currentTheme.colors.textSecondary,
            fontFamily: 'PP Neue Montreal, sans-serif',
            letterSpacing: '0.05em',
          }}
        >
          Filesystem
        </span>
      </div>

      {/* Quick Links */}
      <div className="px-3 py-2 flex flex-wrap gap-1">
        {quickLinks.map((link) => (
          <button
            key={link.path}
            onClick={() => handleNavigate(link.path)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] transition-all duration-150"
            style={{
              color: currentTheme.colors.textSecondary,
              background: 'rgba(255, 255, 255, 0.04)',
              fontFamily: 'IBM Plex Mono, monospace',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.08)';
              e.currentTarget.style.color = currentTheme.colors.textPrimary;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.04)';
              e.currentTarget.style.color = currentTheme.colors.textSecondary;
            }}
          >
            {link.icon}
            {link.label}
          </button>
        ))}
      </div>

      {/* Divider */}
      <div style={{ height: 1, background: 'rgba(255, 255, 255, 0.06)', margin: '0 16px' }} />

      {/* Tree View */}
      <div className="flex-1 overflow-y-auto py-2" style={{ scrollbarWidth: 'thin', scrollbarColor: 'rgba(255,255,255,0.08) transparent' }}>
        <TreeItem
          node={filesystem}
          path="/"
          depth={0}
          currentDir={currentDirectory}
          onNavigate={handleNavigate}
        />
      </div>
    </aside>
  );
}
