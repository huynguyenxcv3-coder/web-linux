import { useState, useEffect, useRef } from 'react';
import { getTheme } from '@/lib/themes';
import type { ThemeName } from '@/types';

interface BootSequenceProps {
  theme: ThemeName;
}

const kernelMessages = [
  '[    0.000000] Booting WebLinux kernel 2.0.0-virtual...',
  '[    0.004200] Command line: root=/dev/sda1 ro quiet',
  '[    0.008100] x86/fpu: Supporting XSAVE feature',
  '[    0.012400] AGP: Checking aperture...',
  '[    0.018000] PCI: Using configuration type 1',
  '[    0.024500] SCSI subsystem initialized',
  '[    0.030200] VFS: Mounted root (ext4 filesystem)',
  '[    0.035800] devtmpfs: initialized',
  '[    0.041000] Freeing unused kernel memory',
  '[    0.045600] Run /sbin/init as init process',
];

const serviceMessages = [
  '[  OK  ] Started kernel.',
  '[  OK  ] Mounted /proc.',
  '[  OK  ] Mounted /sys.',
  '[  OK  ] Started udev.',
  '[  OK  ] Mounted /dev/pts.',
  '[  OK  ] Started networking.',
  '[  OK  ] Mounted /tmp.',
  '[  OK  ] Reached target network.',
  '[  OK  ] Started ssh.',
  '[  OK  ] Reached target multi-user.',
];

export default function BootSequence({ theme }: BootSequenceProps) {
  const currentTheme = getTheme(theme);
  const [phase, setPhase] = useState(0);
  const [visibleMessages, setVisibleMessages] = useState<string[]>([]);
  const [progress, setProgress] = useState(0);
  const [titleVisible, setTitleVisible] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Word constellation canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const words = [
      'kernel', 'shell', 'process', 'filesystem', 'network',
      'memory', 'root', 'daemon', 'pipe', 'fork', 'signal',
      'mount', 'inode', 'syscall', 'boot', 'init', 'bash',
      'terminal', 'linux', 'unix', 'posix', 'thread',
      'socket', 'packet', 'router', 'firewall', 'encrypt',
    ];

    interface WordParticle {
      word: string;
      x: number;
      y: number;
      targetX: number;
      targetY: number;
      vx: number;
      vy: number;
      size: number;
      opacity: number;
    }

    const particles: WordParticle[] = words.map((word, i) => ({
      word,
      x: Math.random() * canvas.width,
      y: canvas.height + Math.random() * 200,
      targetX: Math.random() * canvas.width,
      targetY: -50,
      vx: 0,
      vy: 0,
      size: 12 + Math.random() * 18,
      opacity: 0.15 + Math.random() * 0.15,
    }));

    let animId: number;
    function animate() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (const p of particles) {
        p.targetY -= 0.3;
        if (p.targetY < -50) {
          p.targetY = canvas.height + 50;
          p.targetX = Math.random() * canvas.width;
        }

        const fx = (p.targetX - p.x) * 0.008;
        const fy = (p.targetY - p.y) * 0.008;
        p.vx += fx;
        p.vy += fy;
        p.vx *= 0.95;
        p.vy *= 0.95;
        p.x += p.vx;
        p.y += p.vy;

        ctx.font = `${p.size}px "IBM Plex Mono", monospace`;
        ctx.fillStyle = `rgba(123, 97, 255, ${p.opacity * (phase >= 7 ? 0.3 : 1)})`;
        ctx.fillText(p.word, p.x, p.y);
      }

      animId = requestAnimationFrame(animate);
    }

    animate();
    return () => cancelAnimationFrame(animId);
  }, [phase]);

  // Phase timing
  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];

    timers.push(setTimeout(() => setTitleVisible(true), 600));
    timers.push(setTimeout(() => setPhase(1), 1200));
    timers.push(setTimeout(() => setPhase(2), 2000));
    timers.push(setTimeout(() => setPhase(3), 3500));
    timers.push(setTimeout(() => setPhase(4), 4500));
    timers.push(setTimeout(() => setPhase(5), 5000));
    timers.push(setTimeout(() => setPhase(6), 5500));
    timers.push(setTimeout(() => setPhase(7), 6000));

    return () => timers.forEach(clearTimeout);
  }, []);

  // Kernel messages
  useEffect(() => {
    if (phase < 1) return;
    let index = 0;
    const interval = setInterval(() => {
      if (index < kernelMessages.length) {
        setVisibleMessages(prev => [...prev, kernelMessages[index]]);
        index++;
      }
      clearInterval(interval);
    }, 80);
    return () => clearInterval(interval);
  }, [phase]);

  // Progress bar
  useEffect(() => {
    if (phase < 2) return;
    let p = 0;
    const interval = setInterval(() => {
      p += 2;
      setProgress(Math.min(p, 100));
      if (p >= 100) clearInterval(interval);
    }, 30);
    return () => clearInterval(interval);
  }, [phase]);

  // Service messages
  useEffect(() => {
    if (phase < 3) return;
    let index = 0;
    const interval = setInterval(() => {
      if (index < serviceMessages.length) {
        setVisibleMessages(prev => [...prev, serviceMessages[index]]);
        index++;
      }
      clearInterval(interval);
    }, 100);
    return () => clearInterval(interval);
  }, [phase]);

  return (
    <div
      className="fixed inset-0 flex flex-col items-center justify-center overflow-hidden"
      style={{ background: '#050505' }}
    >
      {/* Constellation Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0"
        style={{ opacity: phase >= 7 ? 0.3 : 0.6, transition: 'opacity 0.6s ease' }}
      />

      {/* Vignette */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at center, rgba(5,5,5,0) 0%, rgba(5,5,5,0.5) 40%, #050505 70%)`,
        }}
      />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center max-w-2xl w-full px-8">
        {/* Title */}
        <div
          className="overflow-hidden transition-all duration-1000"
          style={{
            maxHeight: titleVisible ? 120 : 0,
            opacity: titleVisible ? 1 : 0,
            marginBottom: titleVisible ? 32 : 0,
          }}
        >
          <h1
            className="text-center"
            style={{
              fontFamily: 'Instrument Serif, serif',
              fontSize: 64,
              lineHeight: 1.1,
              color: '#F0F0F2',
              fontWeight: 400,
            }}
          >
            WebLinux OS
          </h1>
        </div>

        {/* Kernel Messages */}
        <div
          className="w-full font-mono text-[11px] space-y-0.5 overflow-hidden transition-all duration-500"
          style={{
            maxHeight: phase >= 1 ? 300 : 0,
            opacity: phase >= 1 ? 1 : 0,
            fontFamily: 'IBM Plex Mono, monospace',
            color: 'rgba(255, 255, 255, 0.5)',
          }}
        >
          {visibleMessages.map((msg, i) => (
            <div key={i} className="truncate">
              {msg.includes('[  OK  ]') ? (
                <span>
                  <span style={{ color: '#00E5A0' }}>[  OK  ]</span>
                  <span style={{ color: 'rgba(255, 255, 255, 0.5)' }}>{msg.substring(8)}</span>
                </span>
              ) : (
                msg
              )}
            </div>
          ))}
        </div>

        {/* Progress Bar */}
        <div
          className="w-full max-w-md mt-6 transition-all duration-500"
          style={{
            maxHeight: phase >= 2 ? 20 : 0,
            opacity: phase >= 2 ? 1 : 0,
          }}
        >
          <div
            className="w-full h-1 rounded-full overflow-hidden"
            style={{ background: 'rgba(255, 255, 255, 0.05)' }}
          >
            <div
              className="h-full rounded-full transition-all duration-100"
              style={{
                width: `${progress}%`,
                background: `linear-gradient(90deg, #7B61FF, #00E5A0)`,
              }}
            />
          </div>
          <div className="text-center mt-2 text-[10px] font-mono" style={{ color: 'rgba(255, 255, 255, 0.3)', fontFamily: 'IBM Plex Mono' }}>
            {progress < 100 ? `Booting... ${progress}%` : 'System ready'}
          </div>
        </div>
      </div>
    </div>
  );
}
