import { useState, useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { getTheme } from '@/lib/themes';
import { Menu, PanelRight, PanelLeft, Moon, Terminal, Maximize2, Minimize2 } from 'lucide-react';
import type { ThemeName } from '@/types';

interface TopbarProps {
  onZenMode: (active: boolean) => void;
}

export default function Topbar({ onZenMode }: TopbarProps) {
  const theme = useStore((s) => s.theme);
  const setTheme = useStore((s) => s.setTheme);
  const currentDirectory = useStore((s) => s.currentDirectory);
  const currentUser = useStore((s) => s.currentUser);
  const hostname = useStore((s) => s.hostname);
  const sidebarVisible = useStore((s) => s.sidebarVisible);
  const infoPanelVisible = useStore((s) => s.infoPanelVisible);
  const toggleSidebar = useStore((s) => s.toggleSidebar);
  const toggleInfoPanel = useStore((s) => s.toggleInfoPanel);
  const [time, setTime] = useState(new Date());
  const [themeMenuOpen, setThemeMenuOpen] = useState(false);
  const [isZen, setIsZen] = useState(false);

  const currentTheme = getTheme(theme);

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const displayCwd = currentDirectory === `/home/${currentUser}` ? '~' :
    currentDirectory === '/root' ? '~' :
    currentDirectory;

  const promptSymbol = currentUser === 'root' ? '#' : '$';

  const themes: { name: ThemeName; label: string }[] = [
    { name: 'midnight', label: 'Midnight' },
    { name: 'matrix', label: 'Matrix' },
    { name: 'solarized', label: 'Solarized' },
    { name: 'monokai', label: 'Monokai' },
    { name: 'abyss', label: 'Abyss' },
  ];

  const handleZenToggle = () => {
    const newZen = !isZen;
    setIsZen(newZen);
    onZenMode(newZen);
  };

  return (
    <header
      className="flex items-center justify-between px-3 select-none relative z-50"
      style={{
        height: 48,
        background: 'rgba(15, 15, 20, 0.85)',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        borderBottom: '1px solid rgba(255, 255, 255, 0.06)',
      }}
    >
      {/* Left Section */}
      <div className="flex items-center gap-2">
        <button
          onClick={toggleSidebar}
          className="p-1.5 rounded-md transition-all duration-200 hover:bg-white/5"
          title="Toggle Sidebar (F1)"
        >
          <Menu size={16} style={{ color: currentTheme.colors.textSecondary }} />
        </button>
        <div className="flex items-center gap-1.5">
          <Terminal size={15} style={{ color: currentTheme.colors.accentPrimary }} />
          <span
            className="text-sm font-medium tracking-tight"
            style={{ color: currentTheme.colors.textPrimary, fontFamily: 'PP Neue Montreal, sans-serif' }}
          >
            WebLinux OS
          </span>
          <span
            className="text-[11px] px-1.5 py-0.5 rounded"
            style={{
              color: 'rgba(255, 255, 255, 0.4)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
            }}
          >
            v2.0
          </span>
        </div>
      </div>

      {/* Center Section - Breadcrumb */}
      <div className="hidden md:flex items-center gap-1 font-mono text-[13px]">
        <span style={{ color: currentTheme.colors.accentPrimary, fontWeight: 700 }}>{currentUser}</span>
        <span style={{ color: currentTheme.colors.textSecondary }}>@</span>
        <span style={{ color: currentTheme.colors.textPrimary }}>{hostname}</span>
        <span style={{ color: currentTheme.colors.textSecondary }}>:</span>
        <span style={{ color: currentTheme.colors.accentSecondary }}>{displayCwd}</span>
        <span style={{ color: currentUser === 'root' ? currentTheme.colors.accentError : currentTheme.colors.textPrimary }}>{promptSymbol}</span>
      </div>

      {/* Right Section */}
      <div className="flex items-center gap-1.5">
        {/* Theme Selector */}
        <div className="relative">
          <button
            onClick={() => setThemeMenuOpen(!themeMenuOpen)}
            className="p-1.5 rounded-md transition-all duration-200 hover:bg-white/5 flex items-center gap-1"
            title="Change Theme"
          >
            <Moon size={14} style={{ color: currentTheme.colors.textSecondary }} />
          </button>
          {themeMenuOpen && (
            <>
              <div className="fixed inset-0" onClick={() => setThemeMenuOpen(false)} />
              <div
                className="absolute right-0 top-full mt-1 py-1 rounded-lg min-w-[140px] z-50"
                style={{
                  background: 'rgba(20, 20, 28, 0.95)',
                  backdropFilter: 'blur(20px) saturate(180%)',
                  border: '1px solid rgba(255, 255, 255, 0.08)',
                  boxShadow: '0 8px 32px rgba(0, 0, 0, 0.4)',
                }}
              >
                {themes.map((t) => (
                  <button
                    key={t.name}
                    onClick={() => { setTheme(t.name); setThemeMenuOpen(false); }}
                    className="w-full text-left px-3 py-1.5 text-sm transition-colors duration-150 hover:bg-white/5 flex items-center gap-2"
                    style={{ color: theme === t.name ? currentTheme.colors.accentPrimary : currentTheme.colors.textPrimary }}
                  >
                    {theme === t.name && <span style={{ color: currentTheme.colors.accentPrimary }}>●</span>}
                    {t.label}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Panel Toggles */}
        <button
          onClick={toggleSidebar}
          className="p-1.5 rounded-md transition-all duration-200 hover:bg-white/5"
          title="Toggle Sidebar"
          style={{ opacity: sidebarVisible ? 1 : 0.4 }}
        >
          <PanelLeft size={14} style={{ color: currentTheme.colors.textSecondary }} />
        </button>
        <button
          onClick={toggleInfoPanel}
          className="p-1.5 rounded-md transition-all duration-200 hover:bg-white/5"
          title="Toggle Info Panel"
          style={{ opacity: infoPanelVisible ? 1 : 0.4 }}
        >
          <PanelRight size={14} style={{ color: currentTheme.colors.textSecondary }} />
        </button>

        {/* Zen Mode */}
        <button
          onClick={handleZenToggle}
          className="p-1.5 rounded-md transition-all duration-200 hover:bg-white/5"
          title="Zen Mode (F3)"
        >
          {isZen ? (
            <Minimize2 size={14} style={{ color: currentTheme.colors.textSecondary }} />
          ) : (
            <Maximize2 size={14} style={{ color: currentTheme.colors.textSecondary }} />
          )}
        </button>

        {/* Clock */}
        <span
          className="font-mono text-xs ml-1 tabular-nums"
          style={{ color: currentTheme.colors.textSecondary }}
        >
          {time.toLocaleTimeString('en-US', { hour12: false })}
        </span>

        {/* Status Dot */}
        <div className="flex items-center gap-1 ml-1">
          <span
            className="inline-block w-1.5 h-1.5 rounded-full animate-pulse"
            style={{ background: currentTheme.colors.accentPrimary }}
          />
          <span className="text-[10px] hidden lg:inline" style={{ color: currentTheme.colors.textMuted }}>
            ready
          </span>
        </div>
      </div>
    </header>
  );
}
