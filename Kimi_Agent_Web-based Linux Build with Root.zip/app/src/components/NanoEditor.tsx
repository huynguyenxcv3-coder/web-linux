import { useState, useEffect, useRef, useCallback } from 'react';
import { useStore } from '@/store/useStore';
import { getTheme } from '@/lib/themes';
import { findNode, getNameFromPath, getParentPath } from '@/lib/filesystem';

interface NanoEditorProps {
  filename: string;
  onClose: () => void;
}

export default function NanoEditor({ filename, onClose }: NanoEditorProps) {
  const theme = useStore((s) => s.theme);
  const filesystem = useStore((s) => s.filesystem);
  const setFilesystem = useStore((s) => s.setFilesystem);
  const currentDirectory = useStore((s) => s.currentDirectory);
  const currentTheme = getTheme(theme);

  const displayName = getNameFromPath(filename) || 'untitled';
  const node = findNode(filesystem, filename);
  const [content, setContent] = useState(node?.type === 'file' ? node.content : '');
  const [cursorLine, setCursorLine] = useState(0);
  const [cursorCol, setCursorCol] = useState(0);
  const [modified, setModified] = useState(false);
  const [showSavePrompt, setShowSavePrompt] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Opening animation
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    requestAnimationFrame(() => setVisible(true));
  }, []);

  const handleClose = useCallback(() => {
    if (modified && !showSavePrompt) {
      setShowSavePrompt(true);
      return;
    }
    setVisible(false);
    setTimeout(onClose, 400);
  }, [modified, showSavePrompt, onClose]);

  const handleSave = useCallback(() => {
    const parentPath = getParentPath(filename);
    const name = getNameFromPath(filename);
    const parent = findNode(filesystem, parentPath);

    if (parent && parent.type === 'directory') {
      if (!parent.children) parent.children = {};
      if (parent.children[name]) {
        parent.children[name].content = content;
        parent.children[name].modified = Math.floor(Date.now() / 1000);
        parent.children[name].size = content.length;
      } else {
        parent.children[name] = {
          name,
          type: 'file',
          content,
          permissions: '-rw-r--r--',
          owner: 'root',
          group: 'root',
          size: content.length,
          modified: Math.floor(Date.now() / 1000),
        };
      }
      setFilesystem({ ...filesystem });
    }
    setModified(false);
    setShowSavePrompt(false);
  }, [content, filename, filesystem, setFilesystem]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.ctrlKey && e.key === 'x') {
      e.preventDefault();
      handleClose();
    } else if (e.ctrlKey && e.key === 'o') {
      e.preventDefault();
      handleSave();
    } else if (showSavePrompt) {
      if (e.key === 'y' || e.key === 'Y') {
        handleSave();
        setVisible(false);
        setTimeout(onClose, 400);
      } else if (e.key === 'n' || e.key === 'N') {
        setVisible(false);
        setTimeout(onClose, 400);
      }
    }
  }, [handleClose, handleSave, showSavePrompt, onClose]);

  const handleContentChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    setModified(true);
    const lines = e.target.value.substring(0, e.target.selectionStart).split('\n');
    setCursorLine(lines.length - 1);
    setCursorCol(lines[lines.length - 1].length);
  }, []);

  const lines = content.split('\n');
  const lineNumWidth = String(lines.length).length;

  // Keyboard shortcuts display
  const shortcuts = [
    { key: '^G', label: 'Get Help' },
    { key: '^O', label: 'Write Out' },
    { key: '^W', label: 'Search' },
    { key: '^K', label: 'Cut Text' },
    { key: '^J', label: 'Justify' },
    { key: '^X', label: 'Exit' },
    { key: '^R', label: 'Read File' },
    { key: '^\\\\', label: 'Replace' },
    { key: '^U', label: 'Paste' },
    { key: '^T', label: 'To Spell' },
  ];

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-center justify-center"
      style={{
        background: 'rgba(5, 5, 5, 0.85)',
        backdropFilter: 'blur(8px)',
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) handleClose();
      }}
    >
      <div
        ref={containerRef}
        className="flex flex-col overflow-hidden"
        style={{
          width: 'min(900px, 90vw)',
          height: 'min(600px, 80vh)',
          borderRadius: 14,
          background: currentTheme.colors.surfaceGlass,
          backdropFilter: 'blur(20px) saturate(180%)',
          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          boxShadow: 'inset 0 0 0 1px rgba(255, 255, 255, 0.05), 0 8px 32px rgba(0, 0, 0, 0.3)',
          transform: visible ? 'scale(1) rotateX(0deg)' : 'scale(0.1) rotateX(-15deg)',
          opacity: visible ? 1 : 0,
          transition: 'transform 0.6s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.4s ease',
          perspective: 1200,
        }}
        onKeyDown={handleKeyDown}
        tabIndex={0}
      >
        {/* Title Bar */}
        <div
          className="flex items-center justify-between px-4 flex-shrink-0"
          style={{
            height: 40,
            background: 'rgba(123, 97, 255, 0.1)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.06)',
            borderRadius: '14px 14px 0 0',
          }}
        >
          <span
            className="text-[13px] font-mono"
            style={{ color: currentTheme.colors.accentSecondary, fontFamily: 'IBM Plex Mono' }}
          >
            {displayName}
          </span>
          <span
            className="text-[12px]"
            style={{ color: modified ? currentTheme.colors.accentWarning : 'transparent' }}
          >
            {modified ? '● Modified' : ''}
          </span>
        </div>

        {/* Editing Area */}
        <div className="flex-1 flex overflow-hidden" style={{ background: currentTheme.colors.background }}>
          {/* Line Numbers */}
          <div
            className="flex-shrink-0 overflow-hidden py-3 text-right select-none"
            style={{
              width: 48 + lineNumWidth * 8,
              background: 'rgba(255, 255, 255, 0.01)',
              borderRight: '1px solid rgba(255, 255, 255, 0.04)',
            }}
          >
            {lines.map((_, i) => (
              <div
                key={i}
                className="px-3 text-[12px] leading-6"
                style={{
                  fontFamily: 'IBM Plex Mono, monospace',
                  color: i === cursorLine ? currentTheme.colors.accentSecondary : currentTheme.colors.textMuted,
                }}
              >
                {i + 1}
              </div>
            ))}
          </div>

          {/* Text Area */}
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              value={content}
              onChange={handleContentChange}
              onKeyDown={handleKeyDown}
              className="w-full h-full resize-none outline-none border-none p-3 leading-6"
              style={{
                fontFamily: 'IBM Plex Mono, monospace',
                fontSize: 14,
                color: currentTheme.colors.textPrimary,
                background: 'transparent',
                caretColor: currentTheme.colors.accentSecondary,
                tabSize: 4,
              }}
              spellCheck={false}
              autoFocus
            />
          </div>
        </div>

        {/* Save Prompt */}
        {showSavePrompt && (
          <div
            className="absolute inset-0 flex items-center justify-center"
            style={{ background: 'rgba(5, 5, 5, 0.7)', borderRadius: 14 }}
          >
            <div
              className="px-6 py-4 rounded-lg"
              style={{
                background: currentTheme.colors.surface,
                border: '1px solid rgba(255, 255, 255, 0.1)',
              }}
            >
              <p className="text-sm mb-3" style={{ color: currentTheme.colors.textPrimary }}>
                Save modified buffer (ANSWERING "No" WILL DESTROY CHANGES) ?
              </p>
              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => { handleSave(); setVisible(false); setTimeout(onClose, 400); }}
                  className="px-4 py-1.5 rounded text-sm"
                  style={{ background: 'rgba(0, 229, 160, 0.15)', color: '#00E5A0' }}
                >
                  Yes
                </button>
                <button
                  onClick={() => { setVisible(false); setTimeout(onClose, 400); }}
                  className="px-4 py-1.5 rounded text-sm"
                  style={{ background: 'rgba(255, 77, 109, 0.15)', color: '#FF4D6D' }}
                >
                  No
                </button>
                <button
                  onClick={() => setShowSavePrompt(false)}
                  className="px-4 py-1.5 rounded text-sm"
                  style={{ background: 'rgba(255, 255, 255, 0.05)', color: currentTheme.colors.textSecondary }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Status Bar */}
        <div
          className="flex items-center justify-between px-4 flex-shrink-0"
          style={{
            height: 32,
            background: 'rgba(123, 97, 255, 0.08)',
            borderTop: '1px solid rgba(255, 255, 255, 0.06)',
          }}
        >
          <span className="text-[11px] font-mono" style={{ color: currentTheme.colors.textMuted, fontFamily: 'IBM Plex Mono' }}>
            Ln {cursorLine + 1}, Col {cursorCol + 1}
          </span>
          <span className="text-[11px]" style={{ color: currentTheme.colors.textMuted }}>
            Text
          </span>
          <span className="text-[11px]" style={{ color: currentTheme.colors.textMuted }}>
            UTF-8
          </span>
        </div>

        {/* Shortcut Bar */}
        <div
          className="flex-shrink-0 px-4 py-2 grid grid-cols-5 gap-x-4 gap-y-1"
          style={{
            background: 'rgba(15, 15, 20, 0.5)',
            borderTop: '1px solid rgba(255, 255, 255, 0.04)',
            borderRadius: '0 0 14px 14px',
          }}
        >
          {shortcuts.map((s) => (
            <div key={s.key} className="flex items-center gap-1">
              <span
                className="text-[10px] font-mono px-1 py-0.5 rounded"
                style={{
                  fontFamily: 'IBM Plex Mono',
                  background: 'rgba(255, 255, 255, 0.06)',
                  color: currentTheme.colors.textPrimary,
                }}
              >
                {s.key}
              </span>
              <span className="text-[10px]" style={{ color: currentTheme.colors.textMuted }}>
                {s.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
