import { useState, useRef, useEffect, useCallback } from 'react';
import { useStore } from '@/store/useStore';
import { getTheme } from '@/lib/themes';
import { parseCommandLine, expandVariables } from '@/commands/parser';
import { executeCommand, getAvailableCommands } from '@/commands/index';
import { resolvePath, findNode } from '@/lib/filesystem';

interface TerminalLine {
  id: number;
  type: 'command' | 'output' | 'error' | 'system';
  content: string;
  isLolcat?: boolean;
}

interface TerminalProps {
  onNanoOpen: (filename: string) => void;
  onCMatrix: (active: boolean) => void;
  onZenMode: (active: boolean) => void;
  zenMode: boolean;
}

export default function Terminal({ onNanoOpen, onCMatrix, onZenMode, zenMode }: TerminalProps) {
  const theme = useStore((s) => s.theme);
  const currentDirectory = useStore((s) => s.currentDirectory);
  const currentUser = useStore((s) => s.currentUser);
  const hostname = useStore((s) => s.hostname);
  const environment = useStore((s) => s.environment);
  const commandHistory = useStore((s) => s.commandHistory);
  const historyIndex = useStore((s) => s.historyIndex);
  const aliases = useStore((s) => s.aliases);
  const filesystem = useStore((s) => s.filesystem);
  const addToHistory = useStore((s) => s.addToHistory);
  const setHistoryIndex = useStore((s) => s.setHistoryIndex);
  const currentTheme = getTheme(theme);

  const [lines, setLines] = useState<TerminalLine[]>([]);
  const [input, setInput] = useState('');
  const [cursorPos, setCursorPos] = useState(0);
  const [tabSuggestions, setTabSuggestions] = useState<string[]>([]);
  const [tabIndex, setTabIndex] = useState(-1);
  const [localHistoryIndex, setLocalHistoryIndex] = useState(-1);
  const [showWelcome, setShowWelcome] = useState(true);
  const inputRef = useRef<HTMLInputElement>(null);
  const outputRef = useRef<HTMLDivElement>(null);
  const lineIdRef = useRef(0);

  // Show welcome/MOTD on first load
  useEffect(() => {
    if (showWelcome) {
      const motdNode = findNode(filesystem, '/etc/motd');
      const motdContent = motdNode?.type === 'file' ? motdNode.content : 'Welcome to WebLinux OS v2.0!';
      const welcomeLines: TerminalLine[] = motdContent.split('\n').map((line) => ({
        id: lineIdRef.current++,
        type: 'system' as const,
        content: line,
      }));
      setLines(welcomeLines);
      setShowWelcome(false);
    }
  }, [showWelcome, filesystem]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [lines]);

  // Focus input on click
  const handleTerminalClick = useCallback(() => {
    inputRef.current?.focus();
  }, []);

  const getPrompt = useCallback(() => {
    const displayCwd = currentDirectory === `/home/${currentUser}` ? '~' :
      currentDirectory === '/root' ? '~' :
      currentDirectory;
    const symbol = currentUser === 'root' ? '#' : '$';
    return { user: currentUser, host: hostname, cwd: displayCwd, symbol };
  }, [currentDirectory, currentUser, hostname]);

  const addLine = useCallback((type: TerminalLine['type'], content: string, isLolcat?: boolean) => {
    setLines(prev => [...prev, { id: lineIdRef.current++, type, content, isLolcat }]);
  }, []);

  const handleExecute = useCallback(() => {
    const trimmed = input.trim();
    if (!trimmed) {
      addLine('command', `${getPrompt().user}@${getPrompt().host}:${getPrompt().cwd}${getPrompt().symbol} `);
      return;
    }

    // Show command
    const prompt = getPrompt();
    addLine('command', `${prompt.user}@${prompt.host}:${prompt.cwd}${prompt.symbol} ${trimmed}`);

    // Expand aliases
    let commandStr = trimmed;
    const aliasParts = trimmed.split(/\s+/);
    if (aliases[aliasParts[0]]) {
      commandStr = aliases[aliasParts[0]] + (aliasParts.length > 1 ? ' ' + aliasParts.slice(1).join(' ') : '');
    }

    // Parse and execute
    const parsed = parseCommandLine(commandStr);
    
    // Handle special commands
    if (parsed.command === 'nano') {
      const filename = parsed.args[0] || 'untitled';
      const path = resolvePath(filesystem, currentDirectory, filename);
      addLine('output', `[Opening nano editor: ${filename}]`);
      setInput('');
      setCursorPos(0);
      setTabSuggestions([]);
      setTimeout(() => onNanoOpen(path), 100);
      addToHistory(trimmed);
      return;
    }

    if (parsed.command === 'cmatrix') {
      setInput('');
      setCursorPos(0);
      addToHistory(trimmed);
      setTimeout(() => onCMatrix(true), 100);
      return;
    }

    if (parsed.command === 'exit') {
      addLine('output', 'logout');
      addLine('system', 'Connection closed.');
      setInput('');
      addToHistory(trimmed);
      setTimeout(() => {
        window.location.reload();
      }, 1500);
      return;
    }

    const result = executeCommand(parsed, useStore.getState());

    // Handle special outputs
    if (result.output === '__CLEAR__') {
      setLines([]);
    } else if (result.output === '__CMATRIX__') {
      // Already handled
    } else if (result.output?.startsWith('__LOLCAT__')) {
      const text = result.output.substring(10);
      addLine('output', text, true);
    } else {
      if (result.output) {
        result.output.split('\n').forEach(line => {
          if (line) addLine('output', line);
        });
      }
    }

    if (result.error) {
      result.error.split('\n').forEach(line => {
        if (line) addLine('error', line);
      });
    }

    addToHistory(trimmed);
    setInput('');
    setCursorPos(0);
    setTabSuggestions([]);
    setTabIndex(-1);
    setLocalHistoryIndex(-1);
  }, [input, getPrompt, aliases, filesystem, currentDirectory, addLine, addToHistory, onNanoOpen, onCMatrix]);

  // Tab completion
  const handleTab = useCallback(() => {
    if (tabSuggestions.length > 0 && tabIndex >= 0) {
      // Use selected suggestion
      const parts = input.split(/\s+/);
      parts[parts.length - 1] = tabSuggestions[tabIndex];
      setInput(parts.join(' ') + ' ');
      setTabSuggestions([]);
      setTabIndex(-1);
      return;
    }

    const parts = input.split(/\s+/);
    const lastPart = parts[parts.length - 1];
    if (!lastPart) return;

    const isFirst = parts.length === 1;
    let suggestions: string[] = [];

    if (isFirst) {
      // Command completion
      const commands = getAvailableCommands();
      suggestions = commands.filter(c => c.startsWith(lastPart));
    } else {
      // File completion
      const currentNode = findNode(filesystem, currentDirectory);
      if (currentNode?.type === 'directory' && currentNode.children) {
        const entries = Object.keys(currentNode.children);
        const prefix = lastPart.includes('/') ? lastPart.substring(lastPart.lastIndexOf('/') + 1) : lastPart;
        const dirPrefix = lastPart.includes('/') ? lastPart.substring(0, lastPart.lastIndexOf('/') + 1) : '';
        suggestions = entries.filter(e => e.startsWith(prefix)).map(e => dirPrefix + e);
      }
    }

    if (suggestions.length === 1) {
      parts[parts.length - 1] = suggestions[0];
      setInput(parts.join(' ') + (isFirst ? ' ' : ''));
      setTabSuggestions([]);
    } else if (suggestions.length > 1) {
      setTabSuggestions(suggestions);
      setTabIndex(0);
    }
  }, [input, filesystem, currentDirectory, tabSuggestions, tabIndex]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleExecute();
    } else if (e.key === 'Tab') {
      e.preventDefault();
      handleTab();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      const newIndex = localHistoryIndex < 0 ? commandHistory.length - 1 : Math.max(0, localHistoryIndex - 1);
      setLocalHistoryIndex(newIndex);
      if (commandHistory[newIndex]) {
        setInput(commandHistory[newIndex]);
        setCursorPos(commandHistory[newIndex].length);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      const newIndex = localHistoryIndex >= commandHistory.length - 1 ? -1 : localHistoryIndex + 1;
      setLocalHistoryIndex(newIndex);
      if (newIndex === -1) {
        setInput('');
        setCursorPos(0);
      } else if (commandHistory[newIndex]) {
        setInput(commandHistory[newIndex]);
        setCursorPos(commandHistory[newIndex].length);
      }
    } else if (e.key === 'ArrowLeft') {
      setCursorPos(prev => Math.max(0, prev - 1));
    } else if (e.key === 'ArrowRight') {
      setCursorPos(prev => Math.min(input.length, prev + 1));
    } else if (e.key === 'Home') {
      setCursorPos(0);
    } else if (e.key === 'End') {
      setCursorPos(input.length);
    } else if (e.key === 'Ctrl' || e.key === 'Control') {
      // Ctrl combinations
    }

    // Ctrl shortcuts
    if (e.ctrlKey) {
      if (e.key === 'l') {
        e.preventDefault();
        setLines([]);
      } else if (e.key === 'c') {
        e.preventDefault();
        addLine('command', `${getPrompt().user}@${getPrompt().host}:${getPrompt().cwd}${getPrompt().symbol} ${input}^C`);
        setInput('');
        setCursorPos(0);
      } else if (e.key === 'u') {
        e.preventDefault();
        setInput('');
        setCursorPos(0);
      } else if (e.key === 'a') {
        e.preventDefault();
        setCursorPos(0);
      } else if (e.key === 'e') {
        e.preventDefault();
        setCursorPos(input.length);
      } else if (e.key === 'w') {
        e.preventDefault();
        const beforeCursor = input.substring(0, cursorPos);
        const match = beforeCursor.match(/^(.*\s)?(\S+\s*)$/);
        if (match) {
          const newInput = (match[1] || '') + input.substring(cursorPos);
          setInput(newInput);
          setCursorPos((match[1] || '').length);
        }
      }
    }
  }, [handleExecute, handleTab, commandHistory, localHistoryIndex, input, cursorPos, getPrompt, addLine]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
    setCursorPos(e.target.selectionStart || 0);
    setTabSuggestions([]);
    setTabIndex(-1);
  }, []);

  const handleSelect = useCallback((e: React.SyntheticEvent<HTMLInputElement>) => {
    setCursorPos(e.currentTarget.selectionStart || 0);
  }, []);

  // Handle keyboard shortcuts globally
  useEffect(() => {
    const handleGlobalKey = (e: KeyboardEvent) => {
      if (e.key === 'F1') {
        e.preventDefault();
        useStore.getState().toggleSidebar();
      } else if (e.key === 'F2') {
        e.preventDefault();
        useStore.getState().toggleInfoPanel();
      } else if (e.key === 'F3') {
        e.preventDefault();
        onZenMode(!zenMode);
      }
    };
    window.addEventListener('keydown', handleGlobalKey);
    return () => window.removeEventListener('keydown', handleGlobalKey);
  }, [zenMode, onZenMode]);

  const prompt = getPrompt();

  // Lolcat color generator
  const lolcatColor = (char: string, index: number): string => {
    const hue = (index * 15) % 360;
    return `hsl(${hue}, 90%, 65%)`;
  };

  return (
    <div
      className="flex flex-col h-full relative"
      onClick={handleTerminalClick}
      style={{ background: currentTheme.colors.background }}
    >
      {/* Output Area */}
      <div
        ref={outputRef}
        className="flex-1 overflow-y-auto p-5 font-mono text-sm leading-relaxed"
        style={{
          fontFamily: 'IBM Plex Mono, monospace',
          fontSize: 14,
          lineHeight: 1.6,
          scrollbarWidth: 'thin',
          scrollbarColor: 'rgba(255,255,255,0.08) transparent',
        }}
      >
        {lines.map((line) => (
          <div key={line.id} className="whitespace-pre-wrap break-all">
            {line.type === 'command' && (
              <span>
                <span style={{ color: currentUser === 'root' ? currentTheme.colors.accentPrimary : currentTheme.colors.accentInfo, fontWeight: 700 }}>
                  {line.content.split('@')[0]}
                </span>
                <span style={{ color: currentTheme.colors.textSecondary }}>@</span>
                <span style={{ color: currentTheme.colors.textPrimary }}>
                  {line.content.split('@')[1]?.split(':')[0]}
                </span>
                <span style={{ color: currentTheme.colors.textSecondary }}>:</span>
                <span style={{ color: currentTheme.colors.accentSecondary }}>
                  {line.content.split(':').slice(1).join(':').split(/[\$#]/)[0]}
                </span>
                <span style={{ color: currentUser === 'root' ? currentTheme.colors.accentError : currentTheme.colors.textPrimary }}>
                  {line.content.match(/[\$#]/)?.[0] || ''}
                </span>
                <span style={{ color: currentTheme.colors.textPrimary }}>
                  {' ' + (line.content.split(/[\$#]\s/).slice(1).join('$ ') || '')}
                </span>
              </span>
            )}
            {line.type === 'output' && !line.isLolcat && (
              <span style={{ color: currentTheme.colors.textPrimary }}>{line.content}</span>
            )}
            {line.type === 'output' && line.isLolcat && (
              <span>
                {line.content.split('').map((char, i) => (
                  <span key={i} style={{ color: lolcatColor(char, i) }}>{char}</span>
                ))}
              </span>
            )}
            {line.type === 'error' && (
              <span style={{ color: currentTheme.colors.accentError }}>{line.content}</span>
            )}
            {line.type === 'system' && (
              <span style={{ color: currentTheme.colors.accentSecondary }}>{line.content}</span>
            )}
          </div>
        ))}
      </div>

      {/* Input Line */}
      <div
        className="flex-shrink-0 px-5 py-3 flex items-start gap-1"
        style={{ borderTop: '1px solid rgba(255, 255, 255, 0.04)' }}
      >
        <span className="font-mono text-sm whitespace-nowrap select-none flex-shrink-0" style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 14 }}>
          <span style={{ color: currentUser === 'root' ? currentTheme.colors.accentPrimary : currentTheme.colors.accentInfo, fontWeight: 700 }}>
            {prompt.user}
          </span>
          <span style={{ color: currentTheme.colors.textSecondary }}>@</span>
          <span style={{ color: currentTheme.colors.textPrimary }}>{prompt.host}</span>
          <span style={{ color: currentTheme.colors.textSecondary }}>:</span>
          <span style={{ color: currentTheme.colors.accentSecondary }}>{prompt.cwd}</span>
          <span style={{ color: currentUser === 'root' ? currentTheme.colors.accentError : currentTheme.colors.textPrimary }}>
            {prompt.symbol}
          </span>
          <span style={{ color: currentTheme.colors.textPrimary }}>{' '}</span>
        </span>
        <div className="relative flex-1 min-w-0">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            onSelect={handleSelect}
            className="w-full bg-transparent outline-none font-mono text-sm"
            style={{
              fontFamily: 'IBM Plex Mono, monospace',
              fontSize: 14,
              color: currentTheme.colors.textPrimary,
              caretColor: currentTheme.colors.accentSecondary,
            }}
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            spellCheck={false}
          />
        </div>
      </div>

      {/* Tab Suggestions */}
      {tabSuggestions.length > 0 && (
        <div
          className="flex-shrink-0 px-5 pb-2 flex flex-wrap gap-1"
          style={{ borderTop: '1px solid rgba(255, 255, 255, 0.02)' }}
        >
          {tabSuggestions.map((s, i) => (
            <button
              key={s}
              onClick={(e) => {
                e.stopPropagation();
                const parts = input.split(/\s+/);
                parts[parts.length - 1] = s;
                setInput(parts.join(' ') + ' ');
                setTabSuggestions([]);
                inputRef.current?.focus();
              }}
              className="px-2.5 py-0.5 rounded text-[12px] font-mono transition-colors duration-100"
              style={{
                fontFamily: 'IBM Plex Mono, monospace',
                background: i === tabIndex ? 'rgba(123, 97, 255, 0.2)' : 'rgba(255, 255, 255, 0.05)',
                color: i === tabIndex ? currentTheme.colors.accentSecondary : currentTheme.colors.textSecondary,
                border: i === tabIndex ? '1px solid rgba(123, 97, 255, 0.3)' : '1px solid transparent',
              }}
            >
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
