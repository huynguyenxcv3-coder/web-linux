import { useEffect, useRef, useCallback } from 'react';

interface CMatrixProps {
  onExit: () => void;
  theme: { colors: { background: string; accentPrimary: string; textPrimary: string } };
}

export default function CMatrix({ onExit, theme }: CMatrixProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const chars = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲンABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const fontSize = 14;
    const columns = Math.floor(canvas.width / fontSize);
    const drops: number[] = Array(columns).fill(0).map(() => Math.random() * -100);

    function draw() {
      if (!ctx || !canvas) return;
      ctx.fillStyle = `rgba(5, 5, 5, 0.05)`;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      for (let i = 0; i < drops.length; i++) {
        const char = chars[Math.floor(Math.random() * chars.length)];
        const isHighlight = Math.random() > 0.975;
        ctx.font = `${fontSize}px "IBM Plex Mono", monospace`;
        ctx.fillStyle = isHighlight ? theme.colors.textPrimary : theme.colors.accentPrimary;
        ctx.fillText(char, i * fontSize, drops[i] * fontSize);

        drops[i]++;
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
      }

      animRef.current = requestAnimationFrame(draw);
    }

    draw();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', handleResize);
    };
  }, [theme]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'q' || e.key === 'Q') {
      onExit();
    }
  }, [onExit]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  return (
    <div className="fixed inset-0" style={{ background: theme.colors.background }}>
      <canvas
        ref={canvasRef}
        className="absolute inset-0"
      />
      <div
        className="absolute bottom-4 left-1/2 -translate-x-1/2 text-xs font-mono"
        style={{ color: 'rgba(255, 255, 255, 0.3)', fontFamily: 'IBM Plex Mono' }}
      >
        Press 'q' to exit
      </div>
    </div>
  );
}
