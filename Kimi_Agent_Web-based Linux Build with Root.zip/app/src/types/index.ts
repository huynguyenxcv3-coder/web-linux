export interface FileNode {
  name: string;
  type: 'file' | 'directory' | 'symlink';
  content: string;
  permissions: string;
  owner: string;
  group: string;
  size: number;
  modified: number;
  children?: Record<string, FileNode>;
  target?: string;
}

export interface Process {
  pid: number;
  user: string;
  cpu: number;
  mem: number;
  command: string;
  args?: string;
}

export interface User {
  name: string;
  uid: number;
  gid: number;
  home: string;
  shell: string;
  password?: string;
}

export interface Group {
  name: string;
  gid: number;
  members: string[];
}

export interface CommandResult {
  output: string;
  error?: string;
  exitCode: number;
}

export type ThemeName = 'midnight' | 'matrix' | 'solarized' | 'monokai' | 'abyss';

export interface Theme {
  name: ThemeName;
  label: string;
  colors: {
    background: string;
    surface: string;
    surfaceGlass: string;
    textPrimary: string;
    textSecondary: string;
    textMuted: string;
    accentPrimary: string;
    accentSecondary: string;
    accentWarning: string;
    accentError: string;
    accentInfo: string;
    directory: string;
    executable: string;
  };
}

export interface WebLinuxState {
  filesystem: FileNode;
  currentDirectory: string;
  currentUser: string;
  hostname: string;
  environment: Record<string, string>;
  commandHistory: string[];
  historyIndex: number;
  installedPackages: string[];
  theme: ThemeName;
  sidebarVisible: boolean;
  infoPanelVisible: boolean;
  processes: Process[];
  users: User[];
  groups: Group[];
  bootComplete: boolean;
  lastDirectory: string;
  aliases: Record<string, string>;
}

export interface ParsedCommand {
  command: string;
  args: string[];
  flags: Set<string>;
  flagArgs: Record<string, string>;
  redirects: Redirect[];
  inputFile?: string;
  pipeline: ParsedCommand[];
}

export interface Redirect {
  type: '>' | '>>' | '<';
  file: string;
}
