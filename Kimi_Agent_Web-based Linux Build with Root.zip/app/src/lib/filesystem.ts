import type { FileNode } from '@/types';

export function findNode(fs: FileNode, path: string): FileNode | null {
  if (path === '/' || path === '') return fs;
  const parts = path.split('/').filter(Boolean);
  let current: FileNode = fs;
  for (const part of parts) {
    if (current.type !== 'directory' || !current.children) return null;
    if (part === '..') {
      // handled by resolvePath
      continue;
    }
    if (part === '.') continue;
    const child = current.children[part];
    if (!child) return null;
    if (child.type === 'symlink' && child.target) {
      const resolved = resolvePath(fs, child.target, '');
      const target = findNode(fs, resolved);
      if (!target) return null;
      current = target;
    } else {
      current = child;
    }
  }
  return current;
}

export function resolvePath(fs: FileNode, currentDir: string, target: string): string {
  if (target.startsWith('/')) {
    return normalizePath(target);
  }
  const base = currentDir === '/' ? '' : currentDir;
  return normalizePath(base + '/' + target);
}

function normalizePath(path: string): string {
  const parts = path.split('/').filter(Boolean);
  const stack: string[] = [];
  for (const part of parts) {
    if (part === '..') {
      stack.pop();
    } else if (part !== '.') {
      stack.push(part);
    }
  }
  return '/' + stack.join('/');
}

export function getParentPath(path: string): string {
  const parts = path.split('/').filter(Boolean);
  parts.pop();
  return '/' + parts.join('/');
}

export function getNameFromPath(path: string): string {
  const parts = path.split('/').filter(Boolean);
  return parts[parts.length - 1] || '/';
}

export function createFile(fs: FileNode, parentPath: string, name: string, node: FileNode): boolean {
  const parent = findNode(fs, parentPath);
  if (!parent || parent.type !== 'directory' || !parent.children) return false;
  if (parent.children[name]) return false;
  parent.children[name] = node;
  parent.modified = Math.floor(Date.now() / 1000);
  return true;
}

export function deleteNode(fs: FileNode, parentPath: string, name: string): boolean {
  const parent = findNode(fs, parentPath);
  if (!parent || parent.type !== 'directory' || !parent.children) return false;
  if (!parent.children[name]) return false;
  delete parent.children[name];
  parent.modified = Math.floor(Date.now() / 1000);
  return true;
}

export function moveNode(fs: FileNode, oldParentPath: string, oldName: string, newParentPath: string, newName: string): boolean {
  const oldParent = findNode(fs, oldParentPath);
  const newParent = findNode(fs, newParentPath);
  if (!oldParent || !newParent || oldParent.type !== 'directory' || newParent.type !== 'directory') return false;
  if (!oldParent.children || !oldParent.children[oldName]) return false;
  if (!newParent.children) newParent.children = {};
  if (newParent.children[newName]) return false;
  newParent.children[newName] = { ...oldParent.children[oldName], name: newName };
  delete oldParent.children[oldName];
  oldParent.modified = Math.floor(Date.now() / 1000);
  newParent.modified = Math.floor(Date.now() / 1000);
  return true;
}

export function listDirectory(node: FileNode, showHidden = false): FileNode[] {
  if (node.type !== 'directory' || !node.children) return [];
  const entries = Object.values(node.children);
  if (!showHidden) {
    return entries.filter(e => !e.name.startsWith('.'));
  }
  return entries;
}

export function formatSize(size: number): string {
  if (size < 1024) return `${size}B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)}K`;
  if (size < 1024 * 1024 * 1024) return `${(size / (1024 * 1024)).toFixed(1)}M`;
  return `${(size / (1024 * 1024 * 1024)).toFixed(1)}G`;
}

export function formatPermissions(perms: string): string {
  return perms;
}

export function formatDate(timestamp: number): string {
  const date = new Date(timestamp * 1000);
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = months[date.getMonth()];
  const day = String(date.getDate()).padStart(2, ' ');
  const now = new Date();
  if (date.getFullYear() === now.getFullYear()) {
    const hours = String(date.getHours()).padStart(2, '0');
    const mins = String(date.getMinutes()).padStart(2, '0');
    return `${month} ${day} ${hours}:${mins}`;
  }
  const year = date.getFullYear();
  return `${month} ${day}  ${year}`;
}

export function cloneFS(fs: FileNode): FileNode {
  return JSON.parse(JSON.stringify(fs));
}
