import type { FileNode, User, Group } from '@/types';

export function getUid(user: User): number {
  return user.uid;
}

export function userInGroup(userName: string, groupName: string, groups: Group[]): boolean {
  const group = groups.find(g => g.name === groupName);
  if (!group) return false;
  return group.members.includes(userName) || groupName === userName;
}

export function hasPermission(permissions: string, level: number, operation: 'read' | 'write' | 'execute'): boolean {
  // permissions: e.g., "drwxr-xr-x"
  // level: 1 = owner (positions 1-3), 2 = group (positions 4-6), 3 = other (positions 7-9)
  const offset = (level - 1) * 3;
  const permStr = permissions.substring(1); // remove type char
  const idx = offset + (operation === 'read' ? 0 : operation === 'write' ? 1 : 2);
  return permStr[idx] !== '-';
}

export function checkPermission(
  node: FileNode,
  userName: string,
  uid: number,
  groups: Group[],
  operation: 'read' | 'write' | 'execute'
): boolean {
  if (uid === 0) return true;
  if (node.owner === userName) {
    return hasPermission(node.permissions, 1, operation);
  }
  if (userInGroup(userName, node.group, groups)) {
    return hasPermission(node.permissions, 2, operation);
  }
  return hasPermission(node.permissions, 3, operation);
}

export function parseNumericMode(mode: string): string {
  // Convert numeric mode like "755" to "rwxr-xr-x"
  const num = parseInt(mode, 8);
  if (isNaN(num)) return '';
  const owner = ((num >> 6) & 0o7);
  const group = ((num >> 3) & 0o7);
  const other = (num & 0o7);
  return 'rwxrwxrwx'.split('').map((_, i) => {
    const bit = 1 << (2 - (i % 3));
    const section = i < 3 ? owner : i < 6 ? group : other;
    return (section & bit) ? 'rwx'[i % 3] : '-';
  }).join('');
}

export function applySymbolicMode(current: string, mode: string): string {
  // Simple symbolic mode: u+x, g-w, o=r, a+rw
  let result = current;
  const match = mode.match(/^([ugoa]*)([+-=])([rwx]+)$/);
  if (!match) return result;
  const [, who, op, perms] = match;
  const targets = who === '' || who.includes('a') ? [1, 2, 3] :
    who.includes('u') ? [1] :
    who.includes('g') ? [2] :
    who.includes('o') ? [3] : [1, 2, 3];
  
  for (const level of targets) {
    const offset = (level - 1) * 3;
    for (const perm of perms) {
      const idx = offset + (perm === 'r' ? 0 : perm === 'w' ? 1 : 2);
      if (op === '+') {
        result = result.substring(0, idx + 1) + perm + result.substring(idx + 2);
      } else if (op === '-') {
        result = result.substring(0, idx + 1) + '-' + result.substring(idx + 2);
      } else if (op === '=') {
        result = result.substring(0, offset + 1) + perms.split('').map(p => p).join('').padEnd(3, '-') + result.substring(offset + 4);
      }
    }
  }
  return result;
}
