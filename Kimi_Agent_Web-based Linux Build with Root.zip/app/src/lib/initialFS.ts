import type { FileNode } from '@/types';

function now(): number {
  return Math.floor(Date.now() / 1000);
}

function dir(name: string, permissions = 'drwxr-xr-x', owner = 'root', group = 'root', children: Record<string, FileNode> = {}): FileNode {
  return { name, type: 'directory', content: '', permissions, owner, group, size: 4096, modified: now(), children };
}

function file(name: string, content: string, permissions = '-rw-r--r--', owner = 'root', group = 'root'): FileNode {
  return { name, type: 'file', content, permissions, owner, group, size: content.length, modified: now() };
}

function symlink(name: string, target: string, owner = 'root', group = 'root'): FileNode {
  return { name, type: 'symlink', content: '', permissions: 'lrwxrwxrwx', owner, group, size: target.length, modified: now(), target };
}

export function createInitialFilesystem(): FileNode {
  return dir('', 'drwxr-xr-x', 'root', 'root', {
    'bin': dir('bin', 'drwxr-xr-x', 'root', 'root', {
      'ls': symlink('ls', '/bin/busybox'),
      'cat': symlink('cat', '/bin/busybox'),
      'echo': symlink('echo', '/bin/busybox'),
      'mkdir': symlink('mkdir', '/bin/busybox'),
      'rm': symlink('rm', '/bin/busybox'),
      'cp': symlink('cp', '/bin/busybox'),
      'mv': symlink('mv', '/bin/busybox'),
      'pwd': symlink('pwd', '/bin/busybox'),
      'cd': symlink('cd', '/bin/busybox'),
      'touch': symlink('touch', '/bin/busybox'),
      'grep': symlink('grep', '/bin/busybox'),
      'head': symlink('head', '/bin/busybox'),
      'tail': symlink('tail', '/bin/busybox'),
      'wc': symlink('wc', '/bin/busybox'),
      'sort': symlink('sort', '/bin/busybox'),
      'uniq': symlink('uniq', '/bin/busybox'),
      'chmod': symlink('chmod', '/bin/busybox'),
      'chown': symlink('chown', '/bin/busybox'),
      'ps': symlink('ps', '/bin/busybox'),
      'kill': symlink('kill', '/bin/busybox'),
      'busybox': file('busybox', '#!/bin/sh\n# WebLinux core utilities', '-rwxr-xr-x'),
    }),
    'boot': dir('boot', 'drwxr-xr-x', 'root', 'root', {
      'vmlinuz-2.0.0-virtual': file('vmlinuz-2.0.0-virtual', '[KERNEL IMAGE]', '-rw-r--r--'),
      'initrd.img': file('initrd.img', '[INITRAMFS]', '-rw-r--r--'),
      'grub': dir('grub', 'drwxr-xr-x', 'root', 'root', {
        'grub.cfg': file('grub.cfg', 'set timeout=5\nmenuentry "WebLinux OS" {\n  linux /boot/vmlinuz-2.0.0-virtual root=/dev/sda1\n  initrd /boot/initrd.img\n}'),
      }),
    }),
    'dev': dir('dev', 'drwxr-xr-x', 'root', 'root', {
      'null': file('null', '', 'crw-rw-rw--'),
      'zero': file('zero', '', 'crw-rw-rw--'),
      'random': file('random', '', 'crw-rw-rw--'),
      'urandom': file('urandom', '', 'crw-rw-rw--'),
      'tty': file('tty', '', 'crw-rw-rw--'),
      'tty1': file('tty1', '', 'crw--w----'),
      'tty2': file('tty2', '', 'crw--w----'),
      'pts': dir('pts', 'drwxr-xr-x', 'root', 'root'),
      'stdin': symlink('stdin', '/proc/self/fd/0'),
      'stdout': symlink('stdout', '/proc/self/fd/1'),
      'stderr': symlink('stderr', '/proc/self/fd/2'),
      'sda': file('sda', '', 'brw-rw----'),
      'sda1': file('sda1', '', 'brw-rw----'),
      'loop0': file('loop0', '', 'brw-rw----'),
    }),
    'etc': dir('etc', 'drwxr-xr-x', 'root', 'root', {
      'hostname': file('hostname', 'weblinux'),
      'hosts': file('hosts', '127.0.0.1\tlocalhost\n127.0.1.1\tweblinux\n::1\t\tlocalhost ip6-localhost ip6-loopback\nff02::1\tip6-allnodes\nff02::2\tip6-allrouters'),
      'motd': file('motd', [
        'Welcome to WebLinux OS v2.0!',
        '',
        '  ___  __      __   _          ___  ____',
        ' / _ // /___  / /__(_)__  ____/ _ // __ //',
        '/ // / / __ \\/ //_/ / _ \\/ __/ // / /_/ /',
        '\\____/_/\\___/_/\\__/_/\\___/_/ /____/\\____/',
        '',
        ' * Documentation: https://docs.weblinux.io',
        ' * Support:       https://support.weblinux.io',
        ' * Security:      Run "apt update" regularly',
        '',
        'This is a browser-based Linux simulation.',
        'All operations are client-side only.',
        '',
        `System information as of ${new Date().toLocaleString()}:`,
        '',
      ].join('\n')),
      'os-release': file('os-release', 'PRETTY_NAME="WebLinux OS 2.0"\nNAME="WebLinux OS"\nVERSION_ID="2.0"\nVERSION="2.0 (Virtual)"\nID=weblinux\nID_LIKE=debian\nHOME_URL="https://weblinux.io"\nSUPPORT_URL="https://support.weblinux.io"\nBUG_REPORT_URL="https://bugs.weblinux.io"'),
      'passwd': file('passwd', 'root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\nbin:x:2:2:bin:/bin:/usr/sbin/nologin\nsys:x:3:3:sys:/dev:/usr/sbin/nologin\nguest:x:1000:1000:guest:/home/guest:/bin/bash\nnobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin'),
      'shadow': file('shadow', 'root:$6$webLinux$hashed:19800:0:99999:7:::\ndaemon:*:19800:0:99999:7:::\nguest:$6$webLinux$hashed:19800:0:99999:7:::\nnobody:*:19800:0:99999:7:::', '-rw-r-----'),
      'group': file('group', 'root:x:0:\ndaemon:x:1:\nbin:x:2:\nsys:x:3:\nadm:x:4:\ntty:x:5:\nusers:x:1000:\nsudo:x:27:\nwww-data:x:33:\nnogroup:x:65534:'),
      'profile': file('profile', '# /etc/profile\nexport PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\nexport PS1="\\u@\\h:\\w\\$ "\nexport HOME=/root\nexport TERM=xterm-256color\nexport EDITOR=nano\nexport PAGER=less\n\nalias ll="ls -la"\nalias la="ls -A"\nalias l="ls -CF"\nalias ..="cd .."\nalias ...="cd ../.."\nalias grep="grep --color=auto"\nalias cls="clear"'),
      'resolv.conf': file('resolv.conf', 'nameserver 8.8.8.8\nnameserver 8.8.4.4\nsearch localdomain'),
      'fstab': file('fstab', '# /etc/fstab\n/dev/sda1  /           ext4    defaults    0 1\ntmpfs      /tmp        tmpfs   defaults    0 0\nproc       /proc       proc    defaults    0 0\nsysfs      /sys        sysfs   defaults    0 0'),
      'network': dir('network', 'drwxr-xr-x', 'root', 'root', {
        'interfaces': file('interfaces', 'auto lo\niface lo inet loopback\n\nauto eth0\niface eth0 inet static\n    address 192.168.1.100\n    netmask 255.255.255.0\n    gateway 192.168.1.1\n    dns-nameservers 8.8.8.8 8.8.4.4'),
      }),
      'apt': dir('apt', 'drwxr-xr-x', 'root', 'root', {
        'sources.list': file('sources.list', 'deb http://repo.weblinux.io stable main\ndeb http://repo.weblinux.io stable universe\ndeb http://security.weblinux.io stable-security main'),
      }),
      'ssh': dir('ssh', 'drwxr-xr-x', 'root', 'root', {
        'sshd_config': file('sshd_config', 'Port 22\nPermitRootLogin no\nPasswordAuthentication yes\nPubkeyAuthentication yes\nX11Forwarding no\nMaxAuthTries 3'),
      }),
      'cron.d': dir('cron.d', 'drwxr-xr-x', 'root', 'root'),
    }),
    'home': dir('home', 'drwxr-xr-x', 'root', 'root', {
      'guest': dir('guest', 'drwxr-xr-x', 'guest', 'users', {
        'Documents': dir('Documents', 'drwxr-xr-x', 'guest', 'users', {
          'readme.txt': file('readme.txt', 'Welcome to your home directory!\n\nThis is a guest account.\nFeel free to create files and directories here.', '-rw-r--r--', 'guest', 'users'),
        }),
        'Downloads': dir('Downloads', 'drwxr-xr-x', 'guest', 'users'),
        '.bashrc': file('.bashrc', '# ~/.bashrc\nexport PS1="\\u@\\h:\\w\\$ "\nalias ll="ls -la"\nalias la="ls -A"', '-rw-r--r--', 'guest', 'users'),
        '.profile': file('.profile', '# ~/.profile\nsource ~/.bashrc', '-rw-r--r--', 'guest', 'users'),
      }),
    }),
    'lib': dir('lib', 'drwxr-xr-x', 'root', 'root', {
      'modules': dir('modules', 'drwxr-xr-x', 'root', 'root'),
      'systemd': dir('systemd', 'drwxr-xr-x', 'root', 'root'),
    }),
    'media': dir('media', 'drwxr-xr-x', 'root', 'root'),
    'mnt': dir('mnt', 'drwxr-xr-x', 'root', 'root'),
    'opt': dir('opt', 'drwxr-xr-x', 'root', 'root'),
    'proc': dir('proc', 'drwxr-xr-x', 'root', 'root', {
      'cpuinfo': file('cpuinfo', 'processor\t: 0\nvendor_id\t: WebLinux Virtual CPU\ncpu family\t: 6\nmodel\t\t: 142\nmodel name\t: WebLinux Virtual CPU @ 2.40GHz\nstepping\t: 12\ncpu MHz\t\t: 2400.000\ncache size\t: 8192 KB\nphysical id\t: 0\nsiblings\t: 8\ncore id\t\t: 0\ncpu cores\t: 8\napicid\t\t: 0\ninitial apicid\t: 0\nfpu\t\t: yes\nfpu_exception\t: yes\ncpuid level\t: 27\nwp\t\t: yes\nflags\t\t: fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush mmx fxsr sse sse2 ss ht syscall nx pdpe1gb rdtscp lm constant_tsc arch_perfmon rep_good nopl xtopology cpuid tsc_known_freq pni pclmulqdq ssse3 fma cx16 pcid sse4_1 sse4_2 x2apic movbe popcnt tsc_deadline_timer aes xsave avx f16c rdrand hypervisor lahf_lm abm cpuid_fault invpcid_single pti fsgsbase tsc_adjust bmi1 avx2 smep bmi2 erms invpcid xsaveopt arat\nbugs\t\t: cpu_meltdown spectre_v1 spectre_v2 spec_store_bypass l1tf mds swapgs itlb_multihit mmio_stale_data retbleed\nbogomips\t: 4800.00\nclflush size\t: 64\ncache_alignment\t: 64\naddress sizes\t: 39 bits physical, 48 bits virtual\npower management:\n'),
      'meminfo': file('meminfo', 'MemTotal:       16384000 kB\nMemFree:         8192000 kB\nMemAvailable:   12288000 kB\nBuffers:          524288 kB\nCached:          3670016 kB\nSwapCached:            0 kB\nActive:          4194304 kB\nInactive:        2621440 kB\nActive(anon):    2097152 kB\nInactive(anon):   524288 kB\nActive(file):    2097152 kB\nInactive(file):  2097152 kB\nUnevictable:           0 kB\nMlocked:               0 kB\nSwapTotal:       2097152 kB\nSwapFree:        2097152 kB\nDirty:               128 kB\nWriteback:             0 kB\nAnonPages:       2621440 kB\nMapped:          1572864 kB\nShmem:            262144 kB\nKReclaimable:     524288 kB\nSlab:             786432 kB\nSReclaimable:     524288 kB\nSUnreclaim:       262144 kB\nKernelStack:       49152 kB\nPageTables:       131072 kB\nNFS_Unstable:          0 kB\nBounce:                0 kB\nWritebackTmp:          0 kB\nCommitLimit:    10289152 kB\nCommitted_AS:    5242880 kB\nVmallocTotal:   34359738367 kB\nVmallocUsed:      262144 kB\nVmallocChunk:          0 kB\nPercpu:            65536 kB\nHardwareCorrupted:     0 kB\nAnonHugePages:         0 kB\nShmemHugePages:        0 kB\nShmemPmdMapped:        0 kB\nFileHugePages:         0 kB\nFilePmdMapped:         0 kB\nHugePages_Total:       0\nHugePages_Free:        0\nHugePages_Rsvd:        0\nHugePages_Surp:        0\nHugepagesize:       2048 kB\nHugetlb:               0 kB\nDirectMap4k:      524288 kB\nDirectMap2M:    16777216 kB\n'),
      'uptime': file('uptime', '328472.42 1234567.89'),
      'version': file('version', 'Linux version 2.0.0-virtual (admin@weblinux.io) (gcc version 12.2.0) #1 SMP Mon Jan 1 00:00:00 UTC 2026'),
      'loadavg': file('loadavg', '0.42 0.38 0.35 2/128 1024'),
      'stat': file('stat', 'cpu  123456 7890 12345 9876543 1234 567 890 0 0 0\ncpu0 15432 986 1543 1234567 154 70 111 0 0 0\ncpu1 15432 986 1543 1234567 154 70 111 0 0 0\ncpu2 15432 986 1543 1234567 154 70 111 0 0 0\ncpu3 15432 986 1543 1234567 154 70 111 0 0 0\ncpu4 15432 986 1543 1234567 154 70 111 0 0 0\ncpu5 15432 986 1543 1234567 154 70 111 0 0 0\ncpu6 15432 986 1543 1234567 154 70 111 0 0 0\ncpu7 15432 986 1543 1234567 154 70 111 0 0 0\nintr 123456789 123 456 789 ...\nctxt 987654321\nbtime 1700000000\nprocesses 12345\nprocs_running 2\nprocs_blocked 0\nsoftirq 123456789 12345678 23456789 34567890 45678901 56789012 67890123 78901234 89012345 90123456'),
      'diskstats': file('diskstats', '   8       0 sda 12345 678 901234 5678 9876 543 210987 4321 0 12345 9999 0 0 0 0'),
      'net': dir('net', 'drwxr-xr-x', 'root', 'root', {
        'dev': file('dev', 'Inter-|   Receive                                                |  Transmit\n face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed\n    lo: 1234567    8901    0    0    0     0          0         0  1234567    8901    0    0    0     0       0          0\n  eth0: 98765432  456789  0    0    0     0          0         0  45678901  234567  0    0    0     0       0          0'),
      }),
      'sys': dir('sys', 'drwxr-xr-x', 'root', 'root'),
      'self': dir('self', 'drwxr-xr-x', 'root', 'root'),
    }),
    'root': dir('root', 'drwx------', 'root', 'root', {
      '.bashrc': file('.bashrc', '# ~/.bashrc\nexport PS1="\\u@\\h:\\w# "\nalias ll="ls -laF"\nalias la="ls -A"\nalias l="ls -CF"\nalias ..="cd .."\nalias ...="cd ../.."\nalias grep="grep --color=auto"\nalias cls="clear"\n\n# Root-only aliases\nalias sysinfo="uname -a && cat /proc/meminfo | head -5"\nalias ports="netstat -tlnp"\nalias meminfo="free -h"'),
      '.bash_history': file('.bash_history', 'ls -la\ncd /etc\ncat passwd\napt update\napt install htop\nhtop\ncd ~\nclear', '-rw-------'),
      '.profile': file('.profile', '# ~/.profile\nsource ~/.bashrc', '-rw-r--r--'),
      'notes.txt': file('notes.txt', '# Root Notes\n\n## Important System Files\n- /etc/passwd - User accounts\n- /etc/shadow - Password hashes (RESTRICTED)\n- /etc/hosts - Hostname mappings\n- /var/log/syslog - System logs\n\n## Installed Packages\n- htop\n- curl\n- vim\n\n## TODO\n- [ ] Configure firewall\n- [ ] Set up automated backups\n- [ ] Update SSL certificates'),
    }),
    'run': dir('run', 'drwxr-xr-x', 'root', 'root', {
      'lock': dir('lock', 'drwxr-xr-x', 'root', 'root'),
      'systemd': dir('systemd', 'drwxr-xr-x', 'root', 'root'),
    }),
    'sbin': dir('sbin', 'drwxr-xr-x', 'root', 'root', {
      'init': symlink('init', '/bin/busybox'),
      'reboot': symlink('reboot', '/bin/busybox'),
      'shutdown': symlink('shutdown', '/bin/busybox'),
      'ifconfig': symlink('ifconfig', '/bin/busybox'),
      'fdisk': symlink('fdisk', '/bin/busybox'),
      'mkfs': symlink('mkfs', '/bin/busybox'),
      'fsck': symlink('fsck', '/bin/busybox'),
      'hwclock': symlink('hwclock', '/bin/busybox'),
      'insmod': symlink('insmod', '/bin/busybox'),
      'rmmod': symlink('rmmod', '/bin/busybox'),
      'route': symlink('route', '/bin/busybox'),
    }),
    'sys': dir('sys', 'drwxr-xr-x', 'root', 'root'),
    'tmp': dir('tmp', 'drwxrwxrwt', 'root', 'root', {
      '.X11-unix': dir('.X11-unix', 'drwxrwxrwt', 'root', 'root'),
    }),
    'usr': dir('usr', 'drwxr-xr-x', 'root', 'root', {
      'bin': dir('bin', 'drwxr-xr-x', 'root', 'root', {
        'python3': symlink('python3', '/bin/busybox'),
        'node': symlink('node', '/bin/busybox'),
        'git': symlink('git', '/bin/busybox'),
        'gcc': symlink('gcc', '/bin/busybox'),
        'make': symlink('make', '/bin/busybox'),
        'cmake': symlink('cmake', '/bin/busybox'),
        'docker': symlink('docker', '/bin/busybox'),
        'kubectl': symlink('kubectl', '/bin/busybox'),
        'nano': symlink('nano', '/bin/busybox'),
        'vim': symlink('vim', '/bin/busybox'),
        'htop': symlink('htop', '/bin/busybox'),
      }),
      'lib': dir('lib', 'drwxr-xr-x', 'root', 'root'),
      'local': dir('local', 'drwxr-xr-x', 'root', 'root', {
        'bin': dir('bin', 'drwxr-xr-x', 'root', 'root'),
        'etc': dir('etc', 'drwxr-xr-x', 'root', 'root'),
      }),
      'share': dir('share', 'drwxr-xr-x', 'root', 'root', {
        'man': dir('man', 'drwxr-xr-x', 'root', 'root', {
          'man1': dir('man1', 'drwxr-xr-x', 'root', 'root'),
          'man5': dir('man5', 'drwxr-xr-x', 'root', 'root'),
          'man8': dir('man8', 'drwxr-xr-x', 'root', 'root'),
        }),
        'doc': dir('doc', 'drwxr-xr-x', 'root', 'root'),
      }),
      'games': dir('games', 'drwxr-xr-x', 'root', 'root'),
    }),
    'var': dir('var', 'drwxr-xr-x', 'root', 'root', {
      'log': dir('log', 'drwxr-xr-x', 'root', 'root', {
        'syslog': file('syslog', [
          'Jan  1 00:00:01 weblinux rsyslogd: [origin software="rsyslogd" swVersion="8.2302.0"] start',
          'Jan  1 00:00:02 weblinux kernel: [    0.000000] Linux version 2.0.0-virtual',
          'Jan  1 00:00:03 weblinux systemd[1]: Started kernel.',
          'Jan  1 00:00:04 weblinux systemd[1]: Mounted /proc.',
          'Jan  1 00:00:05 weblinux systemd[1]: Mounted /sys.',
          'Jan  1 00:00:06 weblinux systemd[1]: Started udev.',
          'Jan  1 00:00:07 weblinux systemd[1]: Mounted /dev/pts.',
          'Jan  1 00:00:08 weblinux systemd[1]: Started networking.',
          'Jan  1 00:00:09 weblinux systemd[1]: Reached target network.',
          'Jan  1 00:00:10 weblinux sshd[512]: Server listening on 0.0.0.0 port 22.',
          'Jan  1 00:00:11 weblinux cron[1024]: (CRON) INFO (Running @reboot jobs)',
          'Jan  1 00:00:12 weblinux systemd[1]: Reached target multi-user.',
          'Jan  1 00:00:13 weblinux systemd[1]: Startup finished in 3.821s.',
          `Jun 14 10:15:22 weblinux sshd[2048]: Accepted publickey for root from 192.168.1.50 port 54321`,
          `Jun 14 10:15:23 weblinux systemd[1]: Created slice User Slice of UID 0.`,
          `Jun 14 12:30:45 weblinux apt: Installed package htop (3.2.2)`,
          `Jun 14 14:22:01 weblinux cron[1024]: (root) CMD (cd / && run-parts --report /etc/cron.hourly)`,
          `Jun 14 16:45:33 weblinux kernel: [328400.123456] TCP: request_sock_TCP: Possible SYN flooding on port 80. Sending cookies.`,
        ].join('\n')),
        'auth.log': file('auth.log', [
          `Jan  1 00:00:10 weblinux sshd[512]: Server listening on 0.0.0.0 port 22.`,
          `Jan  1 00:00:10 weblinux sshd[512]: Server listening on :: port 22.`,
          `Jun 14 08:12:33 weblinux sshd[2048]: pam_unix(sshd:auth): authentication failure; logname= uid=0 euid=0 tty=ssh ruser= rhost=192.168.1.50`,
          `Jun 14 08:12:35 weblinux sshd[2048]: Failed password for root from 192.168.1.50 port 54321 ssh2`,
          `Jun 14 10:15:22 weblinux sshd[2048]: Accepted publickey for root from 192.168.1.50 port 54321 ssh2: RSA SHA256:AbCdEfGhIjKlMnOpQrStUvWxYz`,
          `Jun 14 10:15:22 weblinux sshd[2048]: pam_unix(sshd:session): session opened for user root(uid=0) by (uid=0)`,
          `Jun 14 10:15:23 weblinux systemd-logind[256]: New session 1 of user root.`,
          `Jun 14 16:30:01 weblinux CRON[4096]: pam_unix(cron:session): session opened for user root(uid=0) by (uid=0)`,
          `Jun 14 16:30:01 weblinux CRON[4096]: pam_unix(cron:session): session closed for user root`,
        ].join('\n')),
        'dpkg.log': file('dpkg.log', [
          `2026-01-01 00:00:10 startup archives unpack`,
          `2026-01-01 00:00:15 install base-files:amd64 <none> 2.0.0`,
          `2026-01-01 00:00:20 status half-installed base-files:amd64 2.0.0`,
          `2026-01-01 00:00:25 status unpacked base-files:amd64 2.0.0`,
          `2026-01-01 00:00:30 configure base-files:amd64 2.0.0`,
          `2026-06-14 12:30:42 startup packages install`,
          `2026-06-14 12:30:45 install htop:amd64 <none> 3.2.2`,
          `2026-06-14 12:30:48 status unpacked htop:amd64 3.2.2`,
          `2026-06-14 12:30:50 configure htop:amd64 3.2.2`,
        ].join('\n')),
        'kern.log': file('kern.log', [
          `Jan  1 00:00:02 weblinux kernel: [    0.000000] Linux version 2.0.0-virtual`,
          `Jan  1 00:00:02 weblinux kernel: [    0.000000] Command line: BOOT_IMAGE=/boot/vmlinuz-2.0.0-virtual root=/dev/sda1 ro quiet`,
          `Jan  1 00:00:02 weblinux kernel: [    0.000000] x86/fpu: Supporting XSAVE feature`,
          `Jan  1 00:00:02 weblinux kernel: [    0.004200] ACPI: Early table checksum verification disabled`,
          `Jan  1 00:00:02 weblinux kernel: [    0.012400] PCI: Using configuration type 1`,
        ].join('\n')),
      }),
      'cache': dir('cache', 'drwxr-xr-x', 'root', 'root', {
        'apt': dir('apt', 'drwxr-xr-x', 'root', 'root', {
          'archives': dir('archives', 'drwxr-xr-x', 'root', 'root'),
        }),
      }),
      'spool': dir('spool', 'drwxr-xr-x', 'root', 'root', {
        'cron': dir('cron', 'drwx--x--x', 'root', 'root'),
        'mail': dir('mail', 'drwxrwsr-x', 'root', 'mail'),
      }),
      'tmp': dir('tmp', 'drwxrwxrwt', 'root', 'root'),
    }),
  });
}
