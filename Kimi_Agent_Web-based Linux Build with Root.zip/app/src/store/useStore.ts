import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { WebLinuxState, FileNode, Process, ThemeName } from '@/types';
import { createInitialFilesystem } from '@/lib/initialFS';

const initialProcesses: Process[] = [
  { pid: 1, user: 'root', cpu: 0.1, mem: 12, command: 'systemd', args: '--system' },
  { pid: 2, user: 'root', cpu: 0.0, mem: 0, command: 'kthreadd' },
  { pid: 512, user: 'root', cpu: 0.2, mem: 8, command: 'sshd', args: '-D' },
  { pid: 1024, user: 'root', cpu: 0.0, mem: 4, command: 'cron' },
  { pid: 2048, user: 'root', cpu: 0.1, mem: 16, command: 'rsyslogd' },
  { pid: 3072, user: 'root', cpu: 0.0, mem: 6, command: 'systemd-networkd' },
  { pid: 4096, user: 'root', cpu: 0.0, mem: 10, command: 'systemd-udevd' },
  { pid: 8192, user: 'root', cpu: 0.5, mem: 48, command: 'bash' },
];

const STORAGE_KEY = 'weblinux_state';

function createDefaultState(): Omit<WebLinuxState, 'bootComplete'> {
  return {
    filesystem: createInitialFilesystem(),
    currentDirectory: '/root',
    currentUser: 'root',
    hostname: 'weblinux',
    environment: {
      PATH: '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
      HOME: '/root',
      TERM: 'xterm-256color',
      EDITOR: 'nano',
      PAGER: 'less',
      PS1: '\\u@\\h:\\w# ',
      SHELL: '/bin/bash',
      USER: 'root',
      LOGNAME: 'root',
      MAIL: '/var/mail/root',
      HOSTNAME: 'weblinux',
      LANG: 'en_US.UTF-8',
      LC_ALL: 'en_US.UTF-8',
    },
    commandHistory: [],
    historyIndex: -1,
    installedPackages: ['coreutils', 'bash', 'apt', 'sshd', 'cron', 'rsyslog', 'nano', 'curl', 'wget', 'vim', 'htop', 'procps', 'net-tools', 'iproute2'],
    theme: 'midnight',
    sidebarVisible: true,
    infoPanelVisible: true,
    processes: initialProcesses,
    users: [
      { name: 'root', uid: 0, gid: 0, home: '/root', shell: '/bin/bash' },
      { name: 'daemon', uid: 1, gid: 1, home: '/usr/sbin', shell: '/usr/sbin/nologin' },
      { name: 'bin', uid: 2, gid: 2, home: '/bin', shell: '/usr/sbin/nologin' },
      { name: 'sys', uid: 3, gid: 3, home: '/dev', shell: '/usr/sbin/nologin' },
      { name: 'guest', uid: 1000, gid: 1000, home: '/home/guest', shell: '/bin/bash' },
      { name: 'nobody', uid: 65534, gid: 65534, home: '/nonexistent', shell: '/usr/sbin/nologin' },
    ],
    groups: [
      { name: 'root', gid: 0, members: ['root'] },
      { name: 'daemon', gid: 1, members: ['daemon'] },
      { name: 'bin', gid: 2, members: ['bin'] },
      { name: 'sys', gid: 3, members: ['sys'] },
      { name: 'adm', gid: 4, members: ['root', 'syslog'] },
      { name: 'tty', gid: 5, members: [] },
      { name: 'users', gid: 1000, members: ['guest'] },
      { name: 'sudo', gid: 27, members: ['root', 'guest'] },
      { name: 'www-data', gid: 33, members: [] },
      { name: 'nogroup', gid: 65534, members: ['nobody'] },
    ],
    lastDirectory: '/root',
    aliases: {
      'll': 'ls -laF',
      'la': 'ls -A',
      'l': 'ls -CF',
      '..': 'cd ..',
      '...': 'cd ../..',
    },
  };
}

interface StoreActions {
  setFilesystem: (fs: FileNode) => void;
  setCurrentDirectory: (dir: string) => void;
  setCurrentUser: (user: string) => void;
  setTheme: (theme: ThemeName) => void;
  toggleSidebar: () => void;
  toggleInfoPanel: () => void;
  setSidebarVisible: (visible: boolean) => void;
  setInfoPanelVisible: (visible: boolean) => void;
  addToHistory: (cmd: string) => void;
  setHistoryIndex: (index: number) => void;
  installPackage: (pkg: string) => void;
  removePackage: (pkg: string) => void;
  updateProcesses: (processes: Process[]) => void;
  addUser: (user: { name: string; uid: number; gid: number; home: string; shell: string }) => void;
  removeUser: (name: string) => void;
  setBootComplete: (complete: boolean) => void;
  setLastDirectory: (dir: string) => void;
  addAlias: (name: string, value: string) => void;
  removeAlias: (name: string) => void;
  resetSystem: () => void;
  setEnvironment: (env: Record<string, string>) => void;
  updateEnvironment: (key: string, value: string) => void;
}

export const useStore = create<WebLinuxState & StoreActions>()(
  persist(
    (set, get) => ({
      ...createDefaultState(),
      bootComplete: false,

      setFilesystem: (fs) => set({ filesystem: fs }),
      setCurrentDirectory: (dir) => set({ currentDirectory: dir, lastDirectory: get().currentDirectory }),
      setCurrentUser: (user) => set({ currentUser: user }),
      setTheme: (theme) => set({ theme }),
      toggleSidebar: () => set((s) => ({ sidebarVisible: !s.sidebarVisible })),
      toggleInfoPanel: () => set((s) => ({ infoPanelVisible: !s.infoPanelVisible })),
      setSidebarVisible: (visible) => set({ sidebarVisible: visible }),
      setInfoPanelVisible: (visible) => set({ infoPanelVisible: visible }),
      addToHistory: (cmd) =>
        set((s) => {
          const history = [...s.commandHistory];
          if (history.length === 0 || history[history.length - 1] !== cmd) {
            history.push(cmd);
            if (history.length > 500) history.shift();
          }
          return { commandHistory: history, historyIndex: history.length };
        }),
      setHistoryIndex: (index) => set({ historyIndex: index }),
      installPackage: (pkg) =>
        set((s) => ({
          installedPackages: s.installedPackages.includes(pkg) ? s.installedPackages : [...s.installedPackages, pkg],
        })),
      removePackage: (pkg) =>
        set((s) => ({
          installedPackages: s.installedPackages.filter((p) => p !== pkg),
        })),
      updateProcesses: (processes) => set({ processes }),
      addUser: (user) =>
        set((s) => ({
          users: [...s.users, user],
        })),
      removeUser: (name) =>
        set((s) => ({
          users: s.users.filter((u) => u.name !== name),
        })),
      setBootComplete: (complete) => set({ bootComplete: complete }),
      setLastDirectory: (dir) => set({ lastDirectory: dir }),
      addAlias: (name, value) =>
        set((s) => ({
          aliases: { ...s.aliases, [name]: value },
        })),
      removeAlias: (name) =>
        set((s) => {
          const aliases = { ...s.aliases };
          delete aliases[name];
          return { aliases };
        }),
      resetSystem: () => {
        localStorage.removeItem(STORAGE_KEY);
        const fresh = createDefaultState();
        set({ ...fresh, bootComplete: true });
      },
      setEnvironment: (env) => set({ environment: env }),
      updateEnvironment: (key, value) =>
        set((s) => ({
          environment: { ...s.environment, [key]: value },
        })),
    }),
    {
      name: STORAGE_KEY,
      partialize: (state) => ({
        filesystem: state.filesystem,
        currentDirectory: state.currentDirectory,
        currentUser: state.currentUser,
        hostname: state.hostname,
        environment: state.environment,
        commandHistory: state.commandHistory,
        historyIndex: state.historyIndex,
        installedPackages: state.installedPackages,
        theme: state.theme,
        sidebarVisible: state.sidebarVisible,
        infoPanelVisible: state.infoPanelVisible,
        users: state.users,
        groups: state.groups,
        lastDirectory: state.lastDirectory,
        aliases: state.aliases,
      }),
    }
  )
);
