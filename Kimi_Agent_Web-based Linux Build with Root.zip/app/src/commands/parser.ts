import type { ParsedCommand } from '@/types';

export function parseCommandLine(input: string): ParsedCommand {
  const trimmed = input.trim();
  if (!trimmed) {
    return { command: '', args: [], flags: new Set(), flagArgs: {}, redirects: [], pipeline: [] };
  }

  // Split by pipes
  const pipelineStages = splitPipeline(trimmed);
  const parsed = pipelineStages.map(parseStage);
  
  if (parsed.length === 0) {
    return { command: '', args: [], flags: new Set(), flagArgs: {}, redirects: [], pipeline: [] };
  }

  const main = parsed[0];
  main.pipeline = parsed.slice(1);
  return main;
}

function splitPipeline(input: string): string[] {
  const stages: string[] = [];
  let current = '';
  let inQuote = false;
  let quoteChar = '';

  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if ((ch === '"' || ch === "'") && !inQuote) {
      inQuote = true;
      quoteChar = ch;
      current += ch;
    } else if (ch === quoteChar && inQuote) {
      inQuote = false;
      quoteChar = '';
      current += ch;
    } else if (ch === '|' && !inQuote) {
      stages.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  if (current.trim()) stages.push(current.trim());
  return stages;
}

function parseStage(input: string): ParsedCommand {
  const redirects: ParsedCommand['redirects'] = [];
  let remaining = input;

  // Extract redirects
  const redirectRegex = /(>\s*\S+|>>\s*\S+|<\s*\S+)/g;
  const redirectMatches = remaining.match(redirectRegex);
  if (redirectMatches) {
    for (const match of redirectMatches) {
      const clean = match.replace(/\s+/g, ' ').trim();
      if (clean.startsWith('>>')) {
        redirects.push({ type: '>>', file: clean.substring(2).trim() });
      } else if (clean.startsWith('>')) {
        redirects.push({ type: '>', file: clean.substring(1).trim() });
      } else if (clean.startsWith('<')) {
        redirects.push({ type: '<', file: clean.substring(1).trim() });
      }
      remaining = remaining.replace(match, '');
    }
  }

  // Tokenize remaining
  const tokens = tokenize(remaining.trim());
  if (tokens.length === 0) {
    return { command: '', args: [], flags: new Set(), flagArgs: {}, redirects, pipeline: [] };
  }

  const command = tokens[0];
  const args: string[] = [];
  const flags = new Set<string>();
  const flagArgs: Record<string, string> = {};

  for (let i = 1; i < tokens.length; i++) {
    const token = tokens[i];
    if (token.startsWith('--') && token.length > 2) {
      const eqIdx = token.indexOf('=');
      if (eqIdx > -1) {
        const flagName = token.substring(2, eqIdx);
        flags.add(flagName);
        flagArgs[flagName] = unquote(token.substring(eqIdx + 1));
      } else {
        flags.add(token.substring(2));
      }
    } else if (token.startsWith('-') && token.length > 1 && !token.startsWith('--')) {
      for (let j = 1; j < token.length; j++) {
        flags.add(token[j]);
      }
    } else {
      args.push(unquote(token));
    }
  }

  return { command, args, flags, flagArgs, redirects, pipeline: [] };
}

function tokenize(input: string): string[] {
  const tokens: string[] = [];
  let current = '';
  let inQuote = false;
  let quoteChar = '';

  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if ((ch === '"' || ch === "'") && !inQuote) {
      inQuote = true;
      quoteChar = ch;
    } else if (ch === quoteChar && inQuote) {
      inQuote = false;
      quoteChar = '';
    } else if (ch === ' ' && !inQuote) {
      if (current) {
        tokens.push(current);
        current = '';
      }
    } else {
      current += ch;
    }
  }
  if (current) tokens.push(current);
  return tokens;
}

function unquote(str: string): string {
  if ((str.startsWith('"') && str.endsWith('"')) || (str.startsWith("'") && str.endsWith("'"))) {
    return str.slice(1, -1);
  }
  return str;
}

export function expandVariables(input: string, env: Record<string, string>): string {
  return input.replace(/\$\{(\w+)\}/g, (_, name) => env[name] || '').replace(/\$(\w+)/g, (_, name) => env[name] || '');
}

export function expandGlob(pattern: string, files: string[]): string[] {
  // Simple glob: * matches anything, ? matches single char
  const regex = new RegExp('^' + pattern.replace(/\./g, '\\.').replace(/\*/g, '.*').replace(/\?/g, '.').replace(/\[/g, '[').replace(/\]/g, ']') + '$');
  return files.filter(f => regex.test(f));
}

export function parseSize(sizeStr: string): number {
  const match = sizeStr.match(/^(\d+)([kmgtp]?)$/i);
  if (!match) return NaN;
  const num = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  const multipliers: Record<string, number> = { '': 1, 'k': 1024, 'm': 1024 * 1024, 'g': 1024 * 1024 * 1024, 't': 1024 ** 4 };
  return num * (multipliers[unit] || 1);
}
