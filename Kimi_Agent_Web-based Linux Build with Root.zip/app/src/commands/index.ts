import type { ParsedCommand, CommandResult, WebLinuxState, FileNode } from '@/types';
import { useStore } from '@/store/useStore';
import { findNode, resolvePath, getParentPath, getNameFromPath, listDirectory, formatSize, formatDate, createFile, deleteNode, moveNode } from '@/lib/filesystem';
import { checkPermission, parseNumericMode, applySymbolicMode } from '@/lib/permissions';
import { expandVariables, expandGlob, parseSize } from './parser';

// Registry of all commands
const commandRegistry: Record<string, (cmd: ParsedCommand, state: WebLinuxState) => CommandResult> = {};

function register(name: string, fn: (cmd: ParsedCommand, state: WebLinuxState) => CommandResult) {
  commandRegistry[name] = fn;
}

export function executeCommand(
  cmd: ParsedCommand,
  state: WebLinuxState,
  input?: string
): CommandResult {
  const fn = commandRegistry[cmd.command];
  if (!fn) {
    return { output: '', error: `${cmd.command}: command not found`, exitCode: 127 };
  }
  try {
    return fn(cmd, state);
  } catch (e) {
    return { output: '', error: `${cmd.command}: ${e instanceof Error ? e.message : 'unknown error'}`, exitCode: 1 };
  }
}

export function getAvailableCommands(): string[] {
  return Object.keys(commandRegistry).sort();
}

function getUser(state: WebLinuxState) {
  return state.users.find(u => u.name === state.currentUser) || state.users[0];
}

function getUid(state: WebLinuxState): number {
  return getUser(state)?.uid || 0;
}

function canRead(node: FileNode, state: WebLinuxState): boolean {
  return checkPermission(node, state.currentUser, getUid(state), state.groups, 'read');
}

function canWrite(node: FileNode, state: WebLinuxState): boolean {
  return checkPermission(node, state.currentUser, getUid(state), state.groups, 'write');
}

function canExecute(node: FileNode, state: WebLinuxState): boolean {
  return checkPermission(node, state.currentUser, getUid(state), state.groups, 'execute');
}

// ===================== FILESYSTEM COMMANDS =====================

register('ls', (cmd, state) => {
  const showAll = cmd.flags.has('a') || cmd.flags.has('all');
  const longFormat = cmd.flags.has('l');
  const humanReadable = cmd.flags.has('h') || cmd.flags.has('human-readable');
  const reverse = cmd.flags.has('r') || cmd.flags.has('reverse');
  const sortByTime = cmd.flags.has('t');
  const sortBySize = cmd.flags.has('S');
  const recursive = cmd.flags.has('R') || cmd.flags.has('recursive');
  const colorize = cmd.flags.has('color') || cmd.flags.has('colour');
  const targetPath = cmd.args[0] ? resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment)) : state.currentDirectory;
  
  const node = findNode(state.filesystem, targetPath);
  if (!node) return { output: '', error: `ls: cannot access '${cmd.args[0] || targetPath}': No such file or directory`, exitCode: 2 };
  if (!canRead(node, state)) return { output: '', error: `ls: cannot open directory '${targetPath}': Permission denied`, exitCode: 2 };

  if (node.type === 'file') {
    if (longFormat) {
      return { output: formatLongLine(node, humanReadable), exitCode: 0 };
    }
    return { output: node.name, exitCode: 0 };
  }

  if (recursive) {
    return { output: formatRecursive(node, targetPath, longFormat, humanReadable, showAll, sortByTime, sortBySize, reverse, state), exitCode: 0 };
  }

  let entries = listDirectory(node, showAll);
  if (sortByTime) entries.sort((a, b) => b.modified - a.modified);
  else if (sortBySize) entries.sort((a, b) => b.size - a.size);
  else entries.sort((a, b) => a.name.localeCompare(b.name));
  if (reverse) entries.reverse();

  if (longFormat) {
    let total = 0;
    for (const e of entries) total += Math.ceil(e.size / 1024);
    const lines = [`total ${total}`, ...entries.map(e => formatLongLine(e, humanReadable))];
    return { output: lines.join('\n'), exitCode: 0 };
  }

  return { output: entries.map(e => e.name).join('  '), exitCode: 0 };
});

function formatLongLine(node: FileNode, humanReadable: boolean): string {
  const size = humanReadable ? formatSize(node.size) : String(node.size);
  const perms = node.permissions;
  const links = node.type === 'directory' ? '2' : '1';
  const owner = node.owner.padEnd(8);
  const group = node.group.padEnd(8);
  const sizeStr = size.padStart(humanReadable ? 5 : 10);
  const date = formatDate(node.modified);
  const name = node.type === 'symlink' ? `${node.name} -> ${node.target}` : node.name;
  return `${perms} ${links} ${owner} ${group} ${sizeStr} ${date} ${name}`;
}

function formatRecursive(node: FileNode, path: string, longFormat: boolean, humanReadable: boolean, showAll: boolean, sortByTime: boolean, sortBySize: boolean, reverse: boolean, state: WebLinuxState): string {
  let result = `${path}:\n`;
  let entries = listDirectory(node, showAll);
  if (sortByTime) entries.sort((a, b) => b.modified - a.modified);
  else if (sortBySize) entries.sort((a, b) => b.size - a.size);
  else entries.sort((a, b) => a.name.localeCompare(b.name));
  if (reverse) entries.reverse();

  if (longFormat) {
    let total = 0;
    for (const e of entries) total += Math.ceil(e.size / 1024);
    result += `total ${total}\n`;
    result += entries.map(e => formatLongLine(e, humanReadable)).join('\n') + '\n';
  } else {
    result += entries.map(e => e.name).join('  ') + '\n';
  }

  for (const entry of entries) {
    if (entry.type === 'directory' && !entry.name.startsWith('.') && canRead(entry, state)) {
      const subPath = path === '/' ? `/${entry.name}` : `${path}/${entry.name}`;
      result += '\n' + formatRecursive(entry, subPath, longFormat, humanReadable, showAll, sortByTime, sortBySize, reverse, state);
    }
  }
  return result;
}

register('cd', (cmd, state) => {
  const target = cmd.args[0] || '~';
  let resolved: string;
  if (target === '~') {
    const user = getUser(state);
    resolved = user.home;
  } else if (target === '-') {
    resolved = state.lastDirectory;
  } else {
    resolved = resolvePath(state.filesystem, state.currentDirectory, expandVariables(target, state.environment));
  }
  const node = findNode(state.filesystem, resolved);
  if (!node) return { output: '', error: `cd: ${target}: No such file or directory`, exitCode: 1 };
  if (node.type !== 'directory') return { output: '', error: `cd: ${target}: Not a directory`, exitCode: 1 };
  if (!canExecute(node, state)) return { output: '', error: `cd: ${target}: Permission denied`, exitCode: 1 };
  
  useStore.getState().setLastDirectory(state.currentDirectory);
  useStore.getState().setCurrentDirectory(resolved);
  return { output: '', exitCode: 0 };
});

register('pwd', (_cmd, state) => {
  return { output: state.currentDirectory, exitCode: 0 };
});

register('cat', (cmd, state) => {
  if (cmd.args.length === 0) return { output: '', exitCode: 0 };
  const showEnds = cmd.flags.has('E');
  const numberLines = cmd.flags.has('n');
  const outputs: string[] = [];
  for (const arg of cmd.args) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(arg, state.environment));
    const node = findNode(state.filesystem, path);
    if (!node) {
      return { output: '', error: `cat: ${arg}: No such file or directory`, exitCode: 1 };
    }
    if (node.type === 'directory') {
      return { output: '', error: `cat: ${arg}: Is a directory`, exitCode: 1 };
    }
    if (!canRead(node, state)) {
      return { output: '', error: `cat: ${arg}: Permission denied`, exitCode: 1 };
    }
    let content = node.content;
    if (numberLines) {
      const lines = content.split('\n');
      content = lines.map((line, i) => `${String(i + 1).padStart(6)}  ${line}`).join('\n');
    }
    if (showEnds) {
      content = content.replace(/\n/g, '$\n');
    }
    outputs.push(content);
  }
  return { output: outputs.join('\n'), exitCode: 0 };
});

register('echo', (cmd, _state) => {
  const noNewline = cmd.flags.has('n');
  const enableEscapes = cmd.flags.has('e');
  let text = cmd.args.join(' ');
  if (enableEscapes) {
    text = text.replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\\\/g, '\\');
  }
  return { output: noNewline ? text : text + '\n', exitCode: 0 };
});

register('mkdir', (cmd, state) => {
  const createParents = cmd.flags.has('p') || cmd.flags.has('parents');
  const modeFlag = cmd.flagArgs['m'] || cmd.flagArgs['mode'];
  let perms = 'drwxr-xr-x';
  if (modeFlag) {
    const parsed = parseNumericMode(modeFlag);
    if (parsed) perms = 'd' + parsed;
  }
  const outputs: string[] = [];
  for (const arg of cmd.args) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(arg, state.environment));
    const parentPath = getParentPath(path);
    const name = getNameFromPath(path);
    const parent = findNode(state.filesystem, parentPath);
    if (!parent) {
      if (createParents) {
        const parts = path.split('/').filter(Boolean);
        let current = '/';
        for (const part of parts) {
          const currentNode = findNode(state.filesystem, current);
          if (currentNode && currentNode.type === 'directory' && currentNode.children && !currentNode.children[part]) {
            if (!canWrite(currentNode, state)) {
              outputs.push(`mkdir: cannot create directory '${path}': Permission denied`);
              break;
            }
            createFile(state.filesystem, current, part, {
              name: part, type: 'directory', content: '', permissions: perms,
              owner: state.currentUser, group: getUser(state).gid === 0 ? 'root' : 'users',
              size: 4096, modified: Math.floor(Date.now() / 1000), children: {}
            });
          }
          current = current === '/' ? `/${part}` : `${current}/${part}`;
        }
        continue;
      }
      outputs.push(`mkdir: cannot create directory '${arg}': No such file or directory`);
      continue;
    }
    if (!canWrite(parent, state)) {
      outputs.push(`mkdir: cannot create directory '${arg}': Permission denied`);
      continue;
    }
    if (parent.type !== 'directory') {
      outputs.push(`mkdir: cannot create directory '${arg}': Not a directory`);
      continue;
    }
    const existing = findNode(state.filesystem, path);
    if (existing) {
      outputs.push(`mkdir: cannot create directory '${arg}': File exists`);
      continue;
    }
    createFile(state.filesystem, parentPath, name, {
      name, type: 'directory', content: '', permissions: perms,
      owner: state.currentUser, group: getUser(state).gid === 0 ? 'root' : 'users',
      size: 4096, modified: Math.floor(Date.now() / 1000), children: {}
    });
  }
  const error = outputs.filter(o => o.includes('cannot') || o.includes('Permission')).join('\n');
  return { output: '', error: error || undefined, exitCode: error ? 1 : 0 };
});

register('rmdir', (cmd, state) => {
  for (const arg of cmd.args) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(arg, state.environment));
    const node = findNode(state.filesystem, path);
    if (!node) return { output: '', error: `rmdir: ${arg}: No such file or directory`, exitCode: 1 };
    if (node.type !== 'directory') return { output: '', error: `rmdir: ${arg}: Not a directory`, exitCode: 1 };
    const children = listDirectory(node, true);
    if (children.length > 0) return { output: '', error: `rmdir: ${arg}: Directory not empty`, exitCode: 1 };
    if (!canWrite(node, state)) return { output: '', error: `rmdir: ${arg}: Permission denied`, exitCode: 1 };
    deleteNode(state.filesystem, getParentPath(path), getNameFromPath(path));
  }
  return { output: '', exitCode: 0 };
});

register('rm', (cmd, state) => {
  const recursive = cmd.flags.has('r') || cmd.flags.has('R') || cmd.flags.has('recursive');
  const force = cmd.flags.has('f') || cmd.flags.has('force');
  const interactive = cmd.flags.has('i') || cmd.flags.has('interactive');
  
  for (const arg of cmd.args) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(arg, state.environment));
    const node = findNode(state.filesystem, path);
    if (!node) {
      if (!force) return { output: '', error: `rm: ${arg}: No such file or directory`, exitCode: 1 };
      continue;
    }
    if (node.type === 'directory' && !recursive) {
      return { output: '', error: `rm: ${arg}: is a directory`, exitCode: 1 };
    }
    const parent = findNode(state.filesystem, getParentPath(path));
    if (parent && !canWrite(parent, state) && !force) {
      return { output: '', error: `rm: ${arg}: Permission denied`, exitCode: 1 };
    }
    deleteNode(state.filesystem, getParentPath(path), getNameFromPath(path));
  }
  return { output: '', exitCode: 0 };
});

register('cp', (cmd, state) => {
  const recursive = cmd.flags.has('r') || cmd.flags.has('R') || cmd.flags.has('recursive');
  if (cmd.args.length < 2) return { output: '', error: 'cp: missing destination file operand', exitCode: 1 };
  const dest = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[cmd.args.length - 1], state.environment));
  const destNode = findNode(state.filesystem, dest);
  const sources = cmd.args.slice(0, -1);
  
  for (const srcArg of sources) {
    const src = resolvePath(state.filesystem, state.currentDirectory, expandVariables(srcArg, state.environment));
    const srcNode = findNode(state.filesystem, src);
    if (!srcNode) return { output: '', error: `cp: ${srcArg}: No such file or directory`, exitCode: 1 };
    if (srcNode.type === 'directory' && !recursive) {
      return { output: '', error: `cp: -r not specified; omitting directory '${srcArg}'`, exitCode: 1 };
    }
    
    const destDir = destNode && destNode.type === 'directory' ? dest : getParentPath(dest);
    const destName = destNode && destNode.type === 'directory' ? srcNode.name : getNameFromPath(dest);
    if (!canWrite(findNode(state.filesystem, destDir) as FileNode, state)) {
      return { output: '', error: `cp: cannot create regular file '${dest}': Permission denied`, exitCode: 1 };
    }
    createFile(state.filesystem, destDir, destName, {
      ...srcNode,
      name: destName,
      modified: Math.floor(Date.now() / 1000),
    });
  }
  return { output: '', exitCode: 0 };
});

register('mv', (cmd, state) => {
  if (cmd.args.length < 2) return { output: '', error: 'mv: missing destination file operand', exitCode: 1 };
  const dest = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[cmd.args.length - 1], state.environment));
  const sources = cmd.args.slice(0, -1);
  
  for (const srcArg of sources) {
    const src = resolvePath(state.filesystem, state.currentDirectory, expandVariables(srcArg, state.environment));
    const srcNode = findNode(state.filesystem, src);
    if (!srcNode) return { output: '', error: `mv: ${srcArg}: No such file or directory`, exitCode: 1 };
    
    const destNode = findNode(state.filesystem, dest);
    const destDir = destNode && destNode.type === 'directory' ? dest : getParentPath(dest);
    const destName = destNode && destNode.type === 'directory' ? srcNode.name : getNameFromPath(dest);
    
    const parent = findNode(state.filesystem, getParentPath(src));
    if (parent && !canWrite(parent, state)) {
      return { output: '', error: `mv: cannot move '${srcArg}' to '${dest}': Permission denied`, exitCode: 1 };
    }
    moveNode(state.filesystem, getParentPath(src), getNameFromPath(src), destDir, destName);
  }
  return { output: '', exitCode: 0 };
});

register('touch', (cmd, state) => {
  for (const arg of cmd.args) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(arg, state.environment));
    const node = findNode(state.filesystem, path);
    if (node) {
      node.modified = Math.floor(Date.now() / 1000);
    } else {
      const parentPath = getParentPath(path);
      const name = getNameFromPath(path);
      const parent = findNode(state.filesystem, parentPath);
      if (parent && canWrite(parent, state)) {
        createFile(state.filesystem, parentPath, name, {
          name, type: 'file', content: '', permissions: '-rw-r--r--',
          owner: state.currentUser, group: getUser(state).gid === 0 ? 'root' : 'users',
          size: 0, modified: Math.floor(Date.now() / 1000),
        });
      }
    }
  }
  return { output: '', exitCode: 0 };
});

register('ln', (cmd, state) => {
  const symbolic = cmd.flags.has('s') || cmd.flags.has('symbolic');
  if (cmd.args.length < 2) return { output: '', error: 'ln: missing file operand', exitCode: 1 };
  const target = cmd.args[0];
  const linkName = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[1], state.environment));
  const parentPath = getParentPath(linkName);
  const name = getNameFromPath(linkName);
  createFile(state.filesystem, parentPath, name, {
    name, type: 'symlink', content: '', permissions: 'lrwxrwxrwx',
    owner: state.currentUser, group: getUser(state).gid === 0 ? 'root' : 'users',
    size: target.length, modified: Math.floor(Date.now() / 1000), target,
  });
  return { output: '', exitCode: 0 };
});

register('find', (cmd, state) => {
  const startPath = cmd.args[0] && !cmd.args[0].startsWith('-') 
    ? resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment))
    : state.currentDirectory;
  let nameFilter = '';
  let typeFilter = '';
  let sizeFilter = '';
  let mtimeFilter = 0;
  
  for (let i = 0; i < cmd.args.length; i++) {
    if (cmd.args[i] === '-name' && i + 1 < cmd.args.length) nameFilter = cmd.args[i + 1];
    if (cmd.args[i] === '-type' && i + 1 < cmd.args.length) typeFilter = cmd.args[i + 1];
    if (cmd.args[i] === '-size' && i + 1 < cmd.args.length) sizeFilter = cmd.args[i + 1];
    if (cmd.args[i] === '-mtime' && i + 1 < cmd.args.length) mtimeFilter = parseInt(cmd.args[i + 1]);
  }
  
  const results: string[] = [];
  function search(node: FileNode, path: string) {
    if (node.type !== 'directory' || !node.children) return;
    for (const [name, child] of Object.entries(node.children)) {
      const childPath = path === '/' ? `/${name}` : `${path}/${name}`;
      let match = true;
      if (nameFilter) {
        const regex = new RegExp('^' + nameFilter.replace(/\*/g, '.*').replace(/\?/g, '.') + '$');
        match = match && regex.test(name);
      }
      if (typeFilter) {
        match = match && ((typeFilter === 'f' && child.type === 'file') || (typeFilter === 'd' && child.type === 'directory') || (typeFilter === 'l' && child.type === 'symlink'));
      }
      if (mtimeFilter) {
        const daysAgo = (Date.now() / 1000 - child.modified) / 86400;
        match = match && daysAgo <= mtimeFilter;
      }
      if (match) results.push(childPath);
      if (child.type === 'directory') search(child, childPath);
    }
  }
  
  const startNode = findNode(state.filesystem, startPath);
  if (startNode) search(startNode, startPath);
  return { output: results.join('\n'), exitCode: 0 };
});

register('grep', (cmd, state) => {
  const ignoreCase = cmd.flags.has('i') || cmd.flags.has('ignore-case');
  const invert = cmd.flags.has('v') || cmd.flags.has('invert-match');
  const lineNumbers = cmd.flags.has('n') || cmd.flags.has('line-number');
  const recursive = cmd.flags.has('r') || cmd.flags.has('R') || cmd.flags.has('recursive');
  const listFiles = cmd.flags.has('l') || cmd.flags.has('files-with-matches');
  const countOnly = cmd.flags.has('c') || cmd.flags.has('count');
  const extended = cmd.flags.has('E') || cmd.flags.has('extended-regexp');
  
  if (cmd.args.length < 1) return { output: '', error: 'grep: missing pattern', exitCode: 2 };
  const pattern = cmd.args[0];
  const files = cmd.args.slice(1);
  const regex = new RegExp(pattern, ignoreCase ? 'i' : '');
  const results: string[] = [];
  
  function grepFile(content: string, filename: string): string[] {
    const lines = content.split('\n');
    const matches: string[] = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const isMatch = regex.test(line);
      const shouldInclude = invert ? !isMatch : isMatch;
      if (shouldInclude) {
        let prefix = '';
        if (files.length > 1 || recursive) prefix = `${filename}:`;
        if (lineNumbers) prefix += `${i + 1}:`;
        matches.push(prefix + line);
      }
    }
    return matches;
  }
  
  if (files.length === 0) {
    // Read from stdin - not supported in this context
    return { output: '', exitCode: 0 };
  }
  
  for (const fileArg of files) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(fileArg, state.environment));
    const node = findNode(state.filesystem, path);
    if (!node) {
      return { output: '', error: `grep: ${fileArg}: No such file or directory`, exitCode: 2 };
    }
    if (node.type === 'directory' && recursive) {
      function searchDir(dir: FileNode, dirPath: string) {
        if (!dir.children) return;
        for (const [name, child] of Object.entries(dir.children)) {
          const childPath = dirPath === '/' ? `/${name}` : `${dirPath}/${name}`;
          if (child.type === 'file' && canRead(child, state)) {
            const matches = grepFile(child.content, childPath);
            if (listFiles && matches.length > 0) results.push(childPath);
            else if (countOnly) results.push(`${childPath}:${matches.length}`);
            else results.push(...matches);
          } else if (child.type === 'directory') {
            searchDir(child, childPath);
          }
        }
      }
      searchDir(node, path);
    } else if (node.type === 'file') {
      const matches = grepFile(node.content, fileArg);
      if (listFiles && matches.length > 0) results.push(fileArg);
      else if (countOnly) results.push(`${fileArg}:${matches.length}`);
      else results.push(...matches);
    }
  }
  return { output: results.join('\n'), exitCode: results.length > 0 ? 0 : 1 };
});

register('head', (cmd, state) => {
  const numLines = cmd.flagArgs['n'] ? parseInt(cmd.flagArgs['n']) : (cmd.args[0] && cmd.args[0].startsWith('-') ? parseInt(cmd.args.shift()!.substring(1)) : 10);
  if (cmd.args.length === 0) return { output: '', exitCode: 0 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node) return { output: '', error: `head: ${cmd.args[0]}: No such file or directory`, exitCode: 1 };
  if (node.type !== 'file') return { output: '', error: `head: ${cmd.args[0]}: Is a directory`, exitCode: 1 };
  const lines = node.content.split('\n').slice(0, numLines);
  return { output: lines.join('\n'), exitCode: 0 };
});

register('tail', (cmd, state) => {
  const numLines = cmd.flagArgs['n'] ? parseInt(cmd.flagArgs['n']) : (cmd.args[0] && cmd.args[0].startsWith('-') ? parseInt(cmd.args.shift()!.substring(1)) : 10);
  if (cmd.args.length === 0) return { output: '', exitCode: 0 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node) return { output: '', error: `tail: ${cmd.args[0]}: No such file or directory`, exitCode: 1 };
  if (node.type !== 'file') return { output: '', error: `tail: ${cmd.args[0]}: Is a directory`, exitCode: 1 };
  const lines = node.content.split('\n').slice(-numLines);
  return { output: lines.join('\n'), exitCode: 0 };
});

register('wc', (cmd, state) => {
  const countLines = cmd.flags.has('l') || cmd.flags.has('lines');
  const countWords = cmd.flags.has('w') || cmd.flags.has('words');
  const countBytes = cmd.flags.has('c') || cmd.flags.has('bytes') || cmd.flags.has('chars');
  const showAll = !countLines && !countWords && !countBytes;
  
  if (cmd.args.length === 0) return { output: '', exitCode: 0 };
  const results: string[] = [];
  
  for (const arg of cmd.args) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(arg, state.environment));
    const node = findNode(state.filesystem, path);
    if (!node || node.type !== 'file') continue;
    const lines = node.content.split('\n').length;
    const words = node.content.trim().split(/\s+/).filter(Boolean).length;
    const bytes = node.content.length;
    const parts: string[] = [];
    if (showAll || countLines) parts.push(String(lines).padStart(8));
    if (showAll || countWords) parts.push(String(words).padStart(8));
    if (showAll || countBytes) parts.push(String(bytes).padStart(8));
    parts.push(arg);
    results.push(parts.join(' '));
  }
  return { output: results.join('\n'), exitCode: 0 };
});

register('sort', (cmd, state) => {
  const reverse = cmd.flags.has('r') || cmd.flags.has('reverse');
  const numeric = cmd.flags.has('n') || cmd.flags.has('numeric-sort');
  const keyField = cmd.flagArgs['k'] ? parseInt(cmd.flagArgs['k']) - 1 : 0;
  const delimiter = cmd.flagArgs['t'] || '\t';
  
  if (cmd.args.length === 0) return { output: '', exitCode: 0 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node || node.type !== 'file') return { output: '', error: `sort: ${cmd.args[0]}: No such file or directory`, exitCode: 2 };
  
  let lines = node.content.split('\n').filter(l => l !== '' || node.content.endsWith('\n'));
  lines.sort((a, b) => {
    const aParts = a.split(delimiter);
    const bParts = b.split(delimiter);
    const aVal = aParts[keyField] || '';
    const bVal = bParts[keyField] || '';
    if (numeric) {
      return reverse ? parseFloat(bVal) - parseFloat(aVal) : parseFloat(aVal) - parseFloat(bVal);
    }
    return reverse ? bVal.localeCompare(aVal) : aVal.localeCompare(bVal);
  });
  return { output: lines.join('\n'), exitCode: 0 };
});

register('uniq', (cmd, state) => {
  const count = cmd.flags.has('c') || cmd.flags.has('count');
  const duplicates = cmd.flags.has('d') || cmd.flags.has('repeated');
  const uniqueOnly = cmd.flags.has('u') || cmd.flags.has('unique');
  
  if (cmd.args.length === 0) return { output: '', exitCode: 0 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node || node.type !== 'file') return { output: '', exitCode: 0 };
  
  const lines = node.content.split('\n');
  const results: string[] = [];
  let prev = '';
  let prevCount = 0;
  
  for (let i = 0; i <= lines.length; i++) {
    const line = lines[i] || '';
    if (line === prev) {
      prevCount++;
    } else {
      if (prevCount > 0) {
        if (count) results.push(`${String(prevCount).padStart(7)} ${prev}`);
        else if (duplicates && prevCount > 1) results.push(prev);
        else if (uniqueOnly && prevCount === 1) results.push(prev);
        else if (!duplicates && !uniqueOnly) results.push(prev);
      }
      prev = line;
      prevCount = 1;
    }
  }
  return { output: results.join('\n'), exitCode: 0 };
});

register('diff', (cmd, state) => {
  if (cmd.args.length < 2) return { output: '', error: 'diff: missing operand', exitCode: 2 };
  const path1 = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const path2 = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[1], state.environment));
  const node1 = findNode(state.filesystem, path1);
  const node2 = findNode(state.filesystem, path2);
  if (!node1 || !node2) return { output: '', error: 'diff: No such file or directory', exitCode: 2 };
  
  const lines1 = node1.content.split('\n');
  const lines2 = node2.content.split('\n');
  const results: string[] = [];
  const maxLen = Math.max(lines1.length, lines2.length);
  
  for (let i = 0; i < maxLen; i++) {
    if (lines1[i] !== lines2[i]) {
      if (lines1[i] !== undefined) results.push(`< ${lines1[i]}`);
      if (lines2[i] !== undefined) results.push(`> ${lines2[i]}`);
    }
  }
  return { output: results.join('\n'), exitCode: results.length > 0 ? 1 : 0 };
});

register('file', (cmd, state) => {
  const results: string[] = [];
  for (const arg of cmd.args) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(arg, state.environment));
    const node = findNode(state.filesystem, path);
    if (!node) {
      results.push(`${arg}: cannot open (No such file or directory)`);
    } else if (node.type === 'directory') {
      results.push(`${arg}: directory`);
    } else if (node.type === 'symlink') {
      results.push(`${arg}: symbolic link to ${node.target}`);
    } else if (node.name.endsWith('.sh')) {
      results.push(`${arg}: POSIX shell script, ASCII text executable`);
    } else if (node.content.startsWith('#!')) {
      results.push(`${arg}: script text executable`);
    } else if (node.content.charCodeAt(0) === 0 || node.content.includes('\x00')) {
      results.push(`${arg}: data`);
    } else {
      results.push(`${arg}: ASCII text`);
    }
  }
  return { output: results.join('\n'), exitCode: 0 };
});

register('stat', (cmd, state) => {
  if (cmd.args.length === 0) return { output: '', error: 'stat: missing operand', exitCode: 1 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node) return { output: '', error: `stat: ${cmd.args[0]}: No such file or directory`, exitCode: 1 };
  
  return {
    output: [
      `  File: ${cmd.args[0]}`,
      `  Size: ${node.size}       Blocks: ${Math.ceil(node.size / 512)}       IO Block: 4096   ${node.type === 'directory' ? 'directory' : 'regular file'}`,
      `Device: 8,1    Inode: ${Math.abs(hashString(path))}    Links: 1`,
      `Access: (${node.permissions.substring(1)})  Uid: (${node.owner})   Gid: (${node.group})`,
      `Access: ${new Date(node.modified * 1000).toISOString()}`,
      `Modify: ${new Date(node.modified * 1000).toISOString()}`,
      `Change: ${new Date(node.modified * 1000).toISOString()}`,
      ` Birth: ${new Date(1700000000000).toISOString()}`,
    ].join('\n'),
    exitCode: 0,
  };
});

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return hash;
}

register('chmod', (cmd, state) => {
  if (cmd.args.length < 2) return { output: '', error: 'chmod: missing operand', exitCode: 1 };
  const mode = cmd.args[0];
  const files = cmd.args.slice(1);
  
  for (const fileArg of files) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(fileArg, state.environment));
    const node = findNode(state.filesystem, path);
    if (!node) return { output: '', error: `chmod: ${fileArg}: No such file or directory`, exitCode: 1 };
    
    let newPerms: string;
    if (/^\d+$/.test(mode)) {
      newPerms = node.permissions[0] + parseNumericMode(mode);
    } else {
      newPerms = applySymbolicMode(node.permissions, mode);
    }
    node.permissions = newPerms;
  }
  return { output: '', exitCode: 0 };
});

register('chown', (cmd, state) => {
  if (cmd.args.length < 2) return { output: '', error: 'chown: missing operand', exitCode: 1 };
  const ownerSpec = cmd.args[0];
  const files = cmd.args.slice(1);
  const [owner, group] = ownerSpec.split(':');
  
  for (const fileArg of files) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(fileArg, state.environment));
    const node = findNode(state.filesystem, path);
    if (!node) return { output: '', error: `chown: ${fileArg}: No such file or directory`, exitCode: 1 };
    if (owner) node.owner = owner;
    if (group) node.group = group;
  }
  return { output: '', exitCode: 0 };
});

register('chgrp', (cmd, state) => {
  if (cmd.args.length < 2) return { output: '', error: 'chgrp: missing operand', exitCode: 1 };
  const group = cmd.args[0];
  const files = cmd.args.slice(1);
  for (const fileArg of files) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(fileArg, state.environment));
    const node = findNode(state.filesystem, path);
    if (!node) return { output: '', error: `chgrp: ${fileArg}: No such file or directory`, exitCode: 1 };
    node.group = group;
  }
  return { output: '', exitCode: 0 };
});

register('du', (cmd, state) => {
  const humanReadable = cmd.flags.has('h') || cmd.flags.has('human-readable');
  const summarize = cmd.flags.has('s') || cmd.flags.has('summarize');
  const allFiles = cmd.flags.has('a') || cmd.flags.has('all');
  const targets = cmd.args.length > 0 ? cmd.args : ['.'];
  const results: string[] = [];
  
  function calcSize(node: FileNode, path: string): number {
    if (node.type === 'file' || node.type === 'symlink') return node.size;
    if (!node.children) return 4096;
    let total = 4096;
    for (const [name, child] of Object.entries(node.children)) {
      const childPath = path === '/' ? `/${name}` : `${path}/${name}`;
      const s = calcSize(child, childPath);
      if (!summarize && (child.type === 'directory' || allFiles)) {
        results.push(`${humanReadable ? formatSize(s) : String(s).padStart(8)}\t${childPath}`);
      }
      total += s;
    }
    if (!summarize || allFiles) {
      results.push(`${humanReadable ? formatSize(total) : String(total).padStart(8)}\t${path}`);
    }
    return total;
  }
  
  for (const target of targets) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(target, state.environment));
    const node = findNode(state.filesystem, path);
    if (!node) continue;
    const total = calcSize(node, path);
    if (summarize) {
      results.push(`${humanReadable ? formatSize(total) : String(total).padStart(8)}\t${path}`);
    }
  }
  return { output: results.join('\n'), exitCode: 0 };
});

register('df', (cmd, _state) => {
  const humanReadable = cmd.flags.has('h') || cmd.flags.has('human-readable');
  const filesystems = [
    { fs: '/dev/sda1', size: 100 * 1024 * 1024 * 1024, used: 42 * 1024 * 1024 * 1024, avail: 53 * 1024 * 1024 * 1024, mounted: '/' },
    { fs: 'tmpfs', size: 8 * 1024 * 1024 * 1024, used: 512 * 1024 * 1024, avail: 7.5 * 1024 * 1024 * 1024, mounted: '/tmp' },
    { fs: 'proc', size: 0, used: 0, avail: 0, mounted: '/proc' },
    { fs: 'sysfs', size: 0, used: 0, avail: 0, mounted: '/sys' },
  ];
  
  const lines = ['Filesystem      Size  Used Avail Use% Mounted on'];
  for (const fs of filesystems) {
    if (fs.size === 0) {
      lines.push(`${fs.fs.padEnd(15)}    -     -     -    - ${fs.mounted}`);
    } else {
      const sizeStr = humanReadable ? formatSize(fs.size) : String(fs.size);
      const usedStr = humanReadable ? formatSize(fs.used) : String(fs.used);
      const availStr = humanReadable ? formatSize(fs.avail) : String(fs.avail);
      const usePct = Math.round((fs.used / fs.size) * 100);
      lines.push(`${fs.fs.padEnd(15)}${sizeStr.padStart(6)}${usedStr.padStart(6)}${availStr.padStart(6)}${String(usePct).padStart(4)}% ${fs.mounted}`);
    }
  }
  return { output: lines.join('\n'), exitCode: 0 };
});

// ===================== SYSTEM COMMANDS =====================

register('ps', (_cmd, state) => {
  const lines = ['  PID USER       %CPU %MEM COMMAND'];
  for (const proc of state.processes) {
    lines.push(`${String(proc.pid).padStart(5)} ${proc.user.padEnd(10)} ${proc.cpu.toFixed(1).padStart(4)} ${proc.mem.toFixed(1).padStart(4)} ${proc.command}${proc.args ? ' ' + proc.args : ''}`);
  }
  return { output: lines.join('\n'), exitCode: 0 };
});

register('top', (_cmd, state) => {
  const uptime = 328472;
  const days = Math.floor(uptime / 86400);
  const hours = Math.floor((uptime % 86400) / 3600);
  const mins = Math.floor((uptime % 3600) / 60);
  const totalMem = 16384000;
  const usedMem = 8192000;
  
  const lines = [
    `top - ${new Date().toLocaleTimeString()} up ${days} days, ${hours}:${String(mins).padStart(2, '0')},  1 user,  load average: 0.42, 0.38, 0.35`,
    `Tasks: ${state.processes.length} total,   2 running, ${state.processes.length - 2} sleeping,   0 stopped,   0 zombie`,
    `%Cpu(s):  2.1 us,  0.8 sy,  0.0 ni, 96.8 id,  0.1 wa,  0.0 hi,  0.2 si,  0.0 st`,
    `MiB Mem : ${(totalMem / 1024).toFixed(1)} total,  ${((totalMem - usedMem) / 1024).toFixed(1)} free,  ${(usedMem / 1024).toFixed(1)} used,  ${(usedMem * 0.3 / 1024).toFixed(1)} buff/cache`,
    `MiB Swap:  2048.0 total,  2048.0 free,    0.0 used.  ${((totalMem - usedMem) / 1024).toFixed(1)} avail Mem`,
    '',
    '  PID USER      PR  NI    VIRT    RES    SHR S  %CPU %MEM     TIME+ COMMAND',
  ];
  
  for (const proc of state.processes) {
    lines.push(`${String(proc.pid).padStart(5)} ${proc.user.padEnd(9)} ${20 + Math.floor(Math.random() * 10)}   0 ${(proc.mem * 1024 + 4000).toString().padStart(7)} ${(proc.mem * 256).toString().padStart(6)} ${(proc.mem * 64).toString().padStart(6)} S  ${proc.cpu.toFixed(1).padStart(4)} ${proc.mem.toFixed(1).padStart(4)}   0:0${Math.floor(Math.random() * 9)}.${Math.floor(Math.random() * 99)} ${proc.command}`);
  }
  return { output: lines.join('\n'), exitCode: 0 };
});

register('htop', (_cmd, state) => {
  // Simplified htop-like output
  const lines = [
    '  PID USER       PRI  NI  VIRT   RES   SHR S CPU% MEM%   TIME+  Command',
    '',
  ];
  for (const proc of state.processes) {
    lines.push(`${String(proc.pid).padStart(5)} ${proc.user.padEnd(10)} ${20}   0 ${(proc.mem * 1024 + 4000).toString().padStart(5)} ${(proc.mem * 256).toString().padStart(5)} ${(proc.mem * 64).toString().padStart(4)} S ${proc.cpu.toFixed(1).padStart(4)} ${proc.mem.toFixed(1).padStart(4)}  0:00.0${Math.floor(Math.random() * 9)} ${proc.command}`);
  }
  return { output: lines.join('\n'), exitCode: 0 };
});

register('uptime', (_cmd, _state) => {
  const uptime = 328472;
  const days = Math.floor(uptime / 86400);
  const hours = Math.floor((uptime % 86400) / 3600);
  const mins = Math.floor((uptime % 3600) / 60);
  const now = new Date();
  return {
    output: `${now.toLocaleTimeString()} up ${days} days, ${hours}:${String(mins).padStart(2, '0')},  1 user,  load average: 0.42, 0.38, 0.35`,
    exitCode: 0,
  };
});

register('whoami', (_cmd, state) => {
  return { output: state.currentUser, exitCode: 0 };
});

register('who', (_cmd, _state) => {
  return { output: 'root     tty1         Jun 14 10:15', exitCode: 0 };
});

register('id', (cmd, state) => {
  const user = cmd.args[0] || state.currentUser;
  const userObj = state.users.find(u => u.name === user);
  if (!userObj) return { output: '', error: `id: '${user}': no such user`, exitCode: 1 };
  const groups = state.groups.filter(g => g.members.includes(user) || g.name === userObj.name);
  const groupStr = groups.map(g => `${g.name}(${g.gid})`).join(',');
  return { output: `uid=${userObj.uid}(${userObj.name}) gid=${userObj.gid}(${userObj.name}) groups=${groupStr}`, exitCode: 0 };
});

register('uname', (cmd, _state) => {
  const all = cmd.flags.has('a') || cmd.flags.has('all');
  const kernel = cmd.flags.has('s') || cmd.flags.has('kernel-name') || all;
  const release = cmd.flags.has('r') || cmd.flags.has('kernel-release') || all;
  const machine = cmd.flags.has('m') || cmd.flags.has('machine') || all;
  
  const parts: string[] = [];
  if (kernel) parts.push('WebLinux');
  if (release) parts.push('2.0.0-virtual');
  if (machine) parts.push('x86_64');
  if (all) parts.push('#1 SMP Mon Jan 1 00:00:00 UTC 2026');
  
  return { output: parts.join(' '), exitCode: 0 };
});

register('hostname', (cmd, state) => {
  if (cmd.args.length > 0) {
    useStore.getState().updateEnvironment('HOSTNAME', cmd.args[0]);
  }
  return { output: state.hostname, exitCode: 0 };
});

register('date', (cmd, _state) => {
  const format = cmd.args[0]?.startsWith('+') ? cmd.args[0].substring(1) : '';
  const now = new Date();
  if (format) {
    // Simple strftime-like formatting
    let result = format;
    result = result.replace(/%Y/g, String(now.getFullYear()));
    result = result.replace(/%m/g, String(now.getMonth() + 1).padStart(2, '0'));
    result = result.replace(/%d/g, String(now.getDate()).padStart(2, '0'));
    result = result.replace(/%H/g, String(now.getHours()).padStart(2, '0'));
    result = result.replace(/%M/g, String(now.getMinutes()).padStart(2, '0'));
    result = result.replace(/%S/g, String(now.getSeconds()).padStart(2, '0'));
    result = result.replace(/%A/g, now.toLocaleDateString('en-US', { weekday: 'long' }));
    result = result.replace(/%B/g, now.toLocaleDateString('en-US', { month: 'long' }));
    result = result.replace(/%Z/g, 'UTC');
    return { output: result, exitCode: 0 };
  }
  return { output: now.toUTCString(), exitCode: 0 };
});

register('cal', (cmd, _state) => {
  const show3 = cmd.flags.has('3');
  const showYear = cmd.flags.has('y') || cmd.flags.has('year');
  const now = new Date();
  const year = cmd.args[0] ? parseInt(cmd.args[0]) : now.getFullYear();
  const month = cmd.args[1] ? parseInt(cmd.args[1]) - 1 : now.getMonth();
  
  if (showYear) {
    const lines: string[] = [`                              ${year}`];
    for (let m = 0; m < 12; m++) {
      lines.push('');
      lines.push(...formatMonth(year, m));
    }
    return { output: lines.join('\n'), exitCode: 0 };
  }
  
  if (show3) {
    // Show 3 months
    const lines: string[] = [];
    for (let m = month - 1; m <= month + 1; m++) {
      const y = m < 0 ? year - 1 : m > 11 ? year + 1 : year;
      const mo = ((m % 12) + 12) % 12;
      lines.push(...formatMonth(y, mo));
      lines.push('');
    }
    return { output: lines.join('\n'), exitCode: 0 };
  }
  
  return { output: formatMonth(year, month).join('\n'), exitCode: 0 };
});

function formatMonth(year: number, month: number): string[] {
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const lines: string[] = [];
  lines.push(`    ${months[month]} ${year}`);
  lines.push('Su Mo Tu We Th Fr Sa');
  let line = ' '.repeat(firstDay * 3);
  for (let d = 1; d <= daysInMonth; d++) {
    line += String(d).padStart(2) + ' ';
    if ((firstDay + d) % 7 === 0 || d === daysInMonth) {
      lines.push(line.trimEnd());
      line = '';
    }
  }
  return lines;
}

register('clear', (_cmd, _state) => {
  return { output: '__CLEAR__', exitCode: 0 };
});

register('env', (_cmd, state) => {
  const lines = Object.entries(state.environment).map(([k, v]) => `${k}=${v}`);
  return { output: lines.join('\n'), exitCode: 0 };
});

register('export', (cmd, state) => {
  for (const arg of cmd.args) {
    const [key, ...valParts] = arg.split('=');
    const value = valParts.join('=');
    useStore.getState().updateEnvironment(key, value);
  }
  return { output: '', exitCode: 0 };
});

register('which', (cmd, _state) => {
  const paths = ['/bin', '/usr/bin', '/sbin', '/usr/sbin', '/usr/local/bin'];
  for (const arg of cmd.args) {
    // Simplified - just show common paths
    if (['ls', 'cat', 'echo', 'mkdir', 'rm', 'cp', 'mv', 'pwd', 'touch', 'grep', 'ps'].includes(arg)) {
      return { output: `/bin/${arg}`, exitCode: 0 };
    }
    if (['python3', 'node', 'git', 'nano', 'vim', 'htop'].includes(arg)) {
      return { output: `/usr/bin/${arg}`, exitCode: 0 };
    }
    if (['ifconfig', 'reboot', 'shutdown'].includes(arg)) {
      return { output: `/sbin/${arg}`, exitCode: 0 };
    }
  }
  return { output: '', exitCode: 1 };
});

register('history', (cmd, state) => {
  if (cmd.flags.has('c')) {
    useStore.getState().setHistoryIndex(-1);
    return { output: '', exitCode: 0 };
  }
  const lines = state.commandHistory.map((h, i) => `  ${String(i + 1).padStart(4)}  ${h}`);
  return { output: lines.join('\n'), exitCode: 0 };
});

// ===================== TEXT PROCESSING COMMANDS =====================

register('awk', (cmd, state) => {
  if (cmd.args.length === 0) return { output: '', error: 'awk: missing program', exitCode: 1 };
  let program = '';
  let fileArg = '';
  
  if (cmd.args[0] === '-F' && cmd.args.length >= 3) {
    // Field separator specified
    program = cmd.args[2];
    fileArg = cmd.args[3] || '';
  } else {
    program = cmd.args[0];
    fileArg = cmd.args[1] || '';
  }
  
  let content = '';
  if (fileArg) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(fileArg, state.environment));
    const node = findNode(state.filesystem, path);
    if (node && node.type === 'file') content = node.content;
  }
  
  const lines = content.split('\n');
  const results: string[] = [];
  
  // Simple awk: support {print $N}, /pattern/, BEGIN, END
  const printMatch = program.match(/\{print\s+([^}]+)\}/);
  const patternMatch = program.match(/^\/(.+)\/\s*\{/);
  const hasBegin = program.includes('BEGIN');
  const hasEnd = program.includes('END');
  
  if (hasBegin) {
    // Ignore BEGIN blocks for simplicity
  }
  
  for (const line of lines) {
    const fields = line.split(/\s+/);
    if (patternMatch) {
      const pattern = new RegExp(patternMatch[1]);
      if (!pattern.test(line)) continue;
    }
    if (printMatch) {
      const expr = printMatch[1].trim();
      if (expr === '$0') {
        results.push(line);
      } else if (expr === '$NF') {
        results.push(fields[fields.length - 1] || '');
      } else {
        const fieldNum = parseInt(expr.replace('$', ''));
        if (!isNaN(fieldNum) && fieldNum > 0) {
          results.push(fields[fieldNum - 1] || '');
        } else {
          results.push(expr);
        }
      }
    }
  }
  
  return { output: results.join('\n'), exitCode: 0 };
});

register('sed', (cmd, state) => {
  if (cmd.args.length === 0) return { output: '', error: 'sed: missing script', exitCode: 1 };
  let script = '';
  let fileArg = '';
  
  if (cmd.args[0] === '-n') {
    script = cmd.args[1];
    fileArg = cmd.args[2] || '';
  } else {
    script = cmd.args[0];
    fileArg = cmd.args[1] || '';
  }
  
  let content = '';
  if (fileArg) {
    const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(fileArg, state.environment));
    const node = findNode(state.filesystem, path);
    if (node && node.type === 'file') content = node.content;
  }
  
  const lines = content.split('\n');
  const results: string[] = [];
  
  // Simple sed: s/old/new/g, p, d
  const substMatch = script.match(/s\/(.+)\/(.+)\/([gi]*)/);
  const deleteMatch = script.match(/(\d+)?d/);
  const printMatch = script.match(/(\d+)?p/);
  
  if (substMatch) {
    const [, old, replacement, flags] = substMatch;
    const global = flags.includes('g');
    const regex = new RegExp(old, global ? 'g' : '');
    for (const line of lines) {
      results.push(line.replace(regex, replacement));
    }
  } else if (deleteMatch) {
    const lineNum = deleteMatch[1] ? parseInt(deleteMatch[1]) : 0;
    for (let i = 0; i < lines.length; i++) {
      if (!lineNum || i + 1 !== lineNum) {
        results.push(lines[i]);
      }
    }
  } else if (printMatch) {
    const lineNum = printMatch[1] ? parseInt(printMatch[1]) : 0;
    for (let i = 0; i < lines.length; i++) {
      if (!lineNum || i + 1 === lineNum) {
        results.push(lines[i]);
      }
    }
  } else {
    results.push(...lines);
  }
  
  return { output: results.join('\n'), exitCode: 0 };
});

register('tr', (cmd, _state) => {
  const deleteMode = cmd.flags.has('d') || cmd.flags.has('delete');
  const squeeze = cmd.flags.has('s') || cmd.flags.has('squeeze-repeats');
  if (cmd.args.length < 2) return { output: '', error: 'tr: missing operand', exitCode: 1 };
  const set1 = cmd.args[0];
  const set2 = cmd.args[1] || '';
  
  // Very simple tr implementation
  if (deleteMode) {
    return { output: set1.split('').filter(c => !set2.includes(c)).join(''), exitCode: 0 };
  }
  
  const map: Record<string, string> = {};
  for (let i = 0; i < set1.length && i < set2.length; i++) {
    map[set1[i]] = set2[i];
  }
  const result = set1.split('').map(c => map[c] || c).join('');
  return { output: result, exitCode: 0 };
});

register('cut', (cmd, state) => {
  const delimiter = cmd.flagArgs['d'] || '\t';
  const fieldSpec = cmd.flagArgs['f'] || '1';
  if (!cmd.args[0]) return { output: '', error: 'cut: missing file', exitCode: 1 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node || node.type !== 'file') return { output: '', error: `cut: ${cmd.args[0]}: No such file or directory`, exitCode: 1 };
  
  const fields = fieldSpec.split(',').map(f => parseInt(f) - 1);
  const lines = node.content.split('\n');
  const results = lines.map(line => {
    const parts = line.split(delimiter);
    return fields.map(f => parts[f] || '').join(delimiter);
  });
  return { output: results.join('\n'), exitCode: 0 };
});

register('tee', (cmd, state) => {
  const append = cmd.flags.has('a') || cmd.flags.has('append');
  // tee reads from stdin and writes to files - simplified
  return { output: '', exitCode: 0 };
});

register('xargs', (cmd, _state) => {
  // xargs builds commands from stdin - simplified
  const command = cmd.args[0] || 'echo';
  return { output: '', exitCode: 0 };
});

register('rev', (cmd, state) => {
  if (!cmd.args[0]) return { output: '', exitCode: 0 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node || node.type !== 'file') return { output: '', exitCode: 0 };
  const lines = node.content.split('\n').map(line => line.split('').reverse().join(''));
  return { output: lines.join('\n'), exitCode: 0 };
});

register('tac', (cmd, state) => {
  if (!cmd.args[0]) return { output: '', exitCode: 0 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node || node.type !== 'file') return { output: '', exitCode: 0 };
  return { output: node.content.split('\n').reverse().join('\n'), exitCode: 0 };
});

register('nl', (cmd, state) => {
  if (!cmd.args[0]) return { output: '', exitCode: 0 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node || node.type !== 'file') return { output: '', exitCode: 0 };
  const lines = node.content.split('\n').map((line, i) => `${String(i + 1).padStart(6)}\t${line}`);
  return { output: lines.join('\n'), exitCode: 0 };
});

register('fold', (cmd, state) => {
  const width = cmd.flagArgs['w'] ? parseInt(cmd.flagArgs['w']) : 80;
  if (!cmd.args[0]) return { output: '', exitCode: 0 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node || node.type !== 'file') return { output: '', exitCode: 0 };
  const lines = node.content.split('\n');
  const results: string[] = [];
  for (const line of lines) {
    for (let i = 0; i < line.length; i += width) {
      results.push(line.substring(i, i + width));
    }
  }
  return { output: results.join('\n'), exitCode: 0 };
});

// ===================== NETWORK COMMANDS =====================

register('ping', (cmd, _state) => {
  const count = cmd.flagArgs['c'] ? parseInt(cmd.flagArgs['c']) : 4;
  const target = cmd.args[0] || 'localhost';
  const results: string[] = [`PING ${target} (127.0.0.1) 56(84) bytes of data.`];
  for (let i = 0; i < count; i++) {
    const time = (0.5 + Math.random() * 2).toFixed(3);
    results.push(`64 bytes from 127.0.0.1: icmp_seq=${i + 1} ttl=64 time=${time} ms`);
  }
  results.push('');
  results.push(`--- ${target} ping statistics ---`);
  results.push(`${count} packets transmitted, ${count} received, 0% packet loss, time ${count * 1000}ms`);
  results.push(`rtt min/avg/max/mdev = 0.512/1.234/2.891/0.456 ms`);
  return { output: results.join('\n'), exitCode: 0 };
});

register('ifconfig', (_cmd, _state) => {
  return {
    output: [
      'eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500',
      '        inet 192.168.1.100  netmask 255.255.255.0  broadcast 192.168.1.255',
      '        inet6 fe80::42:a00ff:fe00:101  prefixlen 64  scopeid 0x20<link>',
      '        ether 02:42:0a:00:00:01  txqueuelen 0  (Ethernet)',
      '        RX packets 1234567  bytes 987654321 (941.8 MiB)',
      '        RX errors 0  dropped 0  overruns 0  frame 0',
      '        TX packets 890123  bytes 456789012 (435.6 MiB)',
      '        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0',
      '',
      'lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536',
      '        inet 127.0.0.1  netmask 255.0.0.0',
      '        inet6 ::1  prefixlen 128  scopeid 0x10<host>',
      '        loop  txqueuelen 1000  (Local Loopback)',
      '        RX packets 8901  bytes 1234567 (1.1 MiB)',
      '        RX errors 0  dropped 0  overruns 0  frame 0',
      '        TX packets 8901  bytes 1234567 (1.1 MiB)',
      '        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0',
    ].join('\n'),
    exitCode: 0,
  };
});

register('ip', (cmd, _state) => {
  const subcmd = cmd.args[0] || '';
  if (subcmd === 'addr' || subcmd === 'a') {
    return {
      output: [
        '1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000',
        '    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00',
        '    inet 127.0.0.1/8 scope host lo',
        '       valid_lft forever preferred_lft forever',
        '2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000',
        '    link/ether 02:42:0a:00:00:01 brd ff:ff:ff:ff:ff:ff',
        '    inet 192.168.1.100/24 brd 192.168.1.255 scope global eth0',
        '       valid_lft forever preferred_lft forever',
      ].join('\n'),
      exitCode: 0,
    };
  }
  if (subcmd === 'link' || subcmd === 'l') {
    return {
      output: [
        '1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000',
        '    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00',
        '2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP mode DEFAULT group default qlen 1000',
        '    link/ether 02:42:0a:00:00:01 brd ff:ff:ff:ff:ff:ff',
      ].join('\n'),
      exitCode: 0,
    };
  }
  if (subcmd === 'route' || subcmd === 'r') {
    return {
      output: [
        'default via 192.168.1.1 dev eth0 proto dhcp metric 100',
        '192.168.1.0/24 dev eth0 proto kernel scope link src 192.168.1.100 metric 100',
      ].join('\n'),
      exitCode: 0,
    };
  }
  return { output: '', error: `ip: unknown command "${subcmd}"`, exitCode: 255 };
});

register('netstat', (cmd, _state) => {
  const tcp = cmd.flags.has('t');
  const udp = cmd.flags.has('u');
  const listening = cmd.flags.has('l');
  const numeric = cmd.flags.has('n');
  
  const lines = ['Proto Recv-Q Send-Q Local Address           Foreign Address         State'];
  const connections = [
    { proto: 'tcp', local: '0.0.0.0:22', foreign: '0.0.0.0:*', state: 'LISTEN' },
    { proto: 'tcp', local: '0.0.0.0:80', foreign: '0.0.0.0:*', state: 'LISTEN' },
    { proto: 'tcp', local: '127.0.0.1:631', foreign: '0.0.0.0:*', state: 'LISTEN' },
    { proto: 'tcp', local: '192.168.1.100:22', foreign: '192.168.1.50:54321', state: 'ESTABLISHED' },
    { proto: 'tcp6', local: ':::22', foreign: ':::*', state: 'LISTEN' },
    { proto: 'udp', local: '0.0.0.0:68', foreign: '0.0.0.0:*', state: '' },
    { proto: 'udp', local: '0.0.0.0:5353', foreign: '0.0.0.0:*', state: '' },
    { proto: 'udp6', local: ':::5353', foreign: ':::*', state: '' },
  ];
  
  for (const conn of connections) {
    if (tcp && !conn.proto.startsWith('tcp')) continue;
    if (udp && !conn.proto.startsWith('udp')) continue;
    if (listening && conn.state !== 'LISTEN') continue;
    lines.push(`${conn.proto.padEnd(6)} ${'0'.padStart(6)} ${'0'.padStart(6)} ${conn.local.padEnd(23)} ${conn.foreign.padEnd(23)} ${conn.state}`);
  }
  return { output: lines.join('\n'), exitCode: 0 };
});

register('ss', (cmd, _state) => {
  const tcp = cmd.flags.has('t');
  const listening = cmd.flags.has('l');
  const numeric = cmd.flags.has('n');
  
  const lines = ['Netid  State   Recv-Q  Send-Q   Local Address:Port    Peer Address:Port  Process'];
  const sockets = [
    { netid: 'tcp', state: 'LISTEN', local: '0.0.0.0:22', peer: '0.0.0.0:*', proc: 'users:(("sshd",pid=512,fd=3))' },
    { netid: 'tcp', state: 'LISTEN', local: '0.0.0.0:80', peer: '0.0.0.0:*', proc: 'users:(("nginx",pid=768,fd=6))' },
    { netid: 'tcp', state: 'ESTAB', local: '192.168.1.100:22', peer: '192.168.1.50:54321', proc: 'users:(("sshd",pid=2048,fd=4))' },
    { netid: 'tcp', state: 'LISTEN', local: '[::]:22', peer: '[::]:*', proc: 'users:(("sshd",pid=512,fd=4))' },
    { netid: 'udp', state: 'UNCONN', local: '0.0.0.0:68', peer: '0.0.0.0:*', proc: 'users:(("dhclient",pid=256,fd=7))' },
  ];
  
  for (const sock of sockets) {
    if (tcp && !sock.netid.startsWith('tcp')) continue;
    if (listening && sock.state !== 'LISTEN') continue;
    lines.push(`${sock.netid.padEnd(6)} ${sock.state.padEnd(7)} ${'0'.padStart(7)} ${'0'.padStart(7)} ${sock.local.padEnd(22)} ${sock.peer.padEnd(22)} ${sock.proc}`);
  }
  return { output: lines.join('\n'), exitCode: 0 };
});

register('curl', (cmd, _state) => {
  const headOnly = cmd.flags.has('I') || cmd.flags.has('head');
  const follow = cmd.flags.has('L') || cmd.flags.has('location');
  const outputFile = cmd.flagArgs['o'];
  const silent = cmd.flags.has('s') || cmd.flags.has('silent');
  const url = cmd.args.find(a => a.startsWith('http')) || cmd.args[cmd.args.length - 1] || 'http://example.com';
  
  if (headOnly) {
    return {
      output: [
        'HTTP/1.1 200 OK',
        'Date: ' + new Date().toUTCString(),
        'Content-Type: text/html; charset=UTF-8',
        'Content-Length: 1256',
        'Connection: keep-alive',
        'Server: nginx/1.24.0',
        'Last-Modified: Mon, 01 Jan 2026 00:00:00 GMT',
        'ETag: "abc123"',
        'Accept-Ranges: bytes',
      ].join('\n'),
      exitCode: 0,
    };
  }
  
  return {
    output: silent ? '' : `<!DOCTYPE html>\n<html>\n<head><title>Example Domain</title></head>\n<body>\n<h1>Example Domain</h1>\n<p>This domain is for use in illustrative examples in documents.</p>\n</body>\n</html>`,
    exitCode: 0,
  };
});

register('wget', (cmd, _state) => {
  const outputFile = cmd.flagArgs['O'];
  const quiet = cmd.flags.has('q') || cmd.flags.has('quiet');
  const url = cmd.args.find(a => a.startsWith('http')) || cmd.args[cmd.args.length - 1] || '';
  
  if (!url) return { output: '', error: 'wget: missing URL', exitCode: 1 };
  
  const filename = outputFile || url.split('/').pop() || 'index.html';
  return {
    output: quiet ? '' : [
      `--${new Date().toUTCString()}--  ${url}`,
      `Resolving ${new URL(url).hostname}... 93.184.216.34`,
      `Connecting to ${new URL(url).hostname}|93.184.216.34|:80... connected.`,
      `HTTP request sent, awaiting response... 200 OK`,
      `Length: 1256 (1.2K) [text/html]`,
      `Saving to: '${filename}'`,
      '',
      `${filename}           100%[===================>]   1.23K  --.-KB/s    in 0.01s`,
      '',
      `${new Date().toUTCString()} (${(Math.random() * 0.1 + 0.01).toFixed(2)} MB/s) - '${filename}' saved [1256/1256]`,
    ].join('\n'),
    exitCode: 0,
  };
});

register('host', (cmd, _state) => {
  const hostname = cmd.args[0] || 'weblinux.io';
  return {
    output: [
      `${hostname} has address 192.168.1.100`,
      `${hostname} has IPv6 address fe80::42:a00ff:fe00:101`,
      `${hostname} mail is handled by 10 mail.${hostname}.`,
    ].join('\n'),
    exitCode: 0,
  };
});

register('nslookup', (cmd, _state) => {
  const hostname = cmd.args[0] || 'weblinux.io';
  return {
    output: [
      'Server:         8.8.8.8',
      'Address:        8.8.8.8#53',
      '',
      `Name:   ${hostname}`,
      'Address: 192.168.1.100',
    ].join('\n'),
    exitCode: 0,
  };
});

register('traceroute', (cmd, _state) => {
  const target = cmd.args[0] || 'weblinux.io';
  const lines = [`traceroute to ${target} (192.168.1.1), 30 hops max, 60 byte packets`];
  const hops = [
    { ip: '192.168.1.1', times: ['0.512', '0.489', '0.501'] },
    { ip: '10.0.0.1', times: ['1.234', '1.198', '1.245'] },
    { ip: '172.16.0.1', times: ['2.567', '2.489', '2.612'] },
    { ip: '203.0.113.1', times: ['5.123', '4.987', '5.234'] },
    { ip: '198.51.100.1', times: ['10.456', '10.234', '10.567'] },
    { ip: '192.168.1.100', times: ['12.345', '12.123', '12.456'] },
  ];
  for (let i = 0; i < hops.length; i++) {
    lines.push(` ${String(i + 1).padStart(2)}  ${hops[i].ip} (${hops[i].ip})  ${hops[i].times[0]} ms  ${hops[i].times[1]} ms  ${hops[i].times[2]} ms`);
  }
  return { output: lines.join('\n'), exitCode: 0 };
});

// ===================== PACKAGE MANAGEMENT =====================

const availablePackages: Record<string, { version: string; description: string; size: string }> = {
  htop: { version: '3.2.2', description: 'Interactive processes viewer', size: '356 kB' },
  vim: { version: '9.0', description: 'Vi IMproved - enhanced vi editor', size: '1,456 kB' },
  emacs: { version: '29.1', description: 'GNU Emacs editor', size: '4,234 kB' },
  nano: { version: '7.2', description: 'Small, friendly text editor', size: '612 kB' },
  git: { version: '2.42.0', description: 'Fast, scalable, distributed revision control system', size: '5,678 kB' },
  curl: { version: '8.4.0', description: 'Command line tool for transferring data with URLs', size: '345 kB' },
  wget: { version: '1.21.4', description: 'Retrieves files from the web', size: '389 kB' },
  apache2: { version: '2.4.57', description: 'Apache HTTP Server', size: '1,234 kB' },
  nginx: { version: '1.24.0', description: 'High performance web server', size: '567 kB' },
  mysql: { version: '8.0.34', description: 'MySQL database server', size: '12,456 kB' },
  postgresql: { version: '15.4', description: 'PostgreSQL database server', size: '8,234 kB' },
  nodejs: { version: '20.8.0', description: 'Node.js event-based server-side javascript engine', size: '15,678 kB' },
  python3: { version: '3.11.6', description: 'Interactive high-level object-oriented language', size: '6,789 kB' },
  gcc: { version: '13.2.0', description: 'GNU C compiler', size: '23,456 kB' },
  make: { version: '4.4.1', description: 'Utility for directing compilation', size: '234 kB' },
  cmake: { version: '3.27.6', description: 'Cross-platform, open-source make system', size: '4,567 kB' },
  docker: { version: '24.0.6', description: 'Linux container runtime', size: '34,567 kB' },
  kubernetes: { version: '1.28.2', description: 'Container orchestration system', size: '45,678 kB' },
  terraform: { version: '1.6.0', description: 'Infrastructure as code tool', size: '56,789 kB' },
  ansible: { version: '8.5.0', description: 'Radically simple IT automation', size: '12,345 kB' },
  redis: { version: '7.2.1', description: 'Persistent key-value database', size: '1,234 kB' },
  mongodb: { version: '7.0.2', description: 'Document-oriented database', size: '23,456 kB' },
  elasticsearch: { version: '8.10.0', description: 'Distributed search engine', size: '67,890 kB' },
  prometheus: { version: '2.47.0', description: 'Monitoring system and time series database', size: '45,678 kB' },
  grafana: { version: '10.1.0', description: 'Feature rich metrics dashboard and graph editor', size: '34,567 kB' },
  jenkins: { version: '2.423', description: 'Extendable open source continuous integration server', size: '56,789 kB' },
  openssl: { version: '3.1.3', description: 'Secure Sockets Layer toolkit', size: '1,234 kB' },
  ssh: { version: '9.4', description: 'Secure shell client and server', size: '1,567 kB' },
  tmux: { version: '3.3a', description: 'Terminal multiplexer', size: '345 kB' },
  screen: { version: '4.9.0', description: 'Terminal multiplexor with VT100/ANSI terminal emulation', size: '456 kB' },
  zsh: { version: '5.9', description: 'Shell with lots of features', size: '2,345 kB' },
  fish: { version: '3.6.1', description: 'Friendly interactive shell', size: '1,678 kB' },
  tree: { version: '2.1.1', description: 'Displays directory tree, in color', size: '45 kB' },
  jq: { version: '1.7', description: 'Lightweight and flexible command-line JSON processor', size: '234 kB' },
  ag: { version: '2.2.0', description: 'Silver searcher - very fast grep-like program', size: '123 kB' },
  fd: { version: '8.7.1', description: 'Simple, fast and user-friendly alternative to find', size: '456 kB' },
  bat: { version: '0.24.0', description: 'Cat clone with syntax highlighting', size: '1,234 kB' },
  exa: { version: '0.10.1', description: 'Modern replacement for ls', size: '567 kB' },
  ripgrep: { version: '13.0.0', description: 'Line-oriented search tool', size: '2,345 kB' },
  fzf: { version: '0.44.0', description: 'General-purpose command-line fuzzy finder', size: '890 kB' },
  neofetch: { version: '7.3.0', description: 'Shows system info with distro art', size: '234 kB' },
  cowsay: { version: '3.7.0', description: 'Configurable talking cow', size: '45 kB' },
  fortune: { version: '1.10.0', description: 'Print a random, hopefully interesting, adage', size: '1,234 kB' },
  sl: { version: '5.02', description: 'Correct you if you type sl by mistake', size: '23 kB' },
  cmatrix: { version: '2.0', description: 'Simulates the display from "The Matrix"', size: '67 kB' },
};

register('apt', (cmd, state) => {
  const subcmd = cmd.args[0] || '';
  const pkgArgs = cmd.args.slice(1);
  
  switch (subcmd) {
    case 'update': {
      return {
        output: [
          'Hit:1 http://repo.weblinux.io stable InRelease',
          'Get:2 http://repo.weblinux.io stable-security InRelease [12.3 kB]',
          'Get:3 http://repo.weblinux.io stable/main amd64 Packages [234 kB]',
          'Get:4 http://repo.weblinux.io stable/universe amd64 Packages [156 kB]',
          'Fetched 402 kB in 1s (402 kB/s)',
          'Reading package lists... Done',
          'Building dependency tree... Done',
          `${Object.keys(availablePackages).length} packages can be upgraded.`,
        ].join('\n'),
        exitCode: 0,
      };
    }
    case 'upgrade':
    case 'full-upgrade': {
      return {
        output: [
          'Reading package lists... Done',
          'Building dependency tree... Done',
          'Calculating upgrade... Done',
          '0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.',
        ].join('\n'),
        exitCode: 0,
      };
    }
    case 'install': {
      if (pkgArgs.length === 0) return { output: '', error: 'apt: missing package name', exitCode: 1 };
      const results: string[] = [];
      for (const pkg of pkgArgs) {
        const info = availablePackages[pkg];
        if (!info) {
          results.push(`E: Unable to locate package ${pkg}`);
          continue;
        }
        if (state.installedPackages.includes(pkg)) {
          results.push(`${pkg} is already the newest version (${info.version}).`);
          continue;
        }
        results.push(`Reading package lists... Done`);
        results.push(`Building dependency tree... Done`);
        results.push(`The following NEW packages will be installed:`);
        results.push(`  ${pkg}`);
        results.push(`0 upgraded, 1 newly installed, 0 to remove and 0 not upgraded.`);
        results.push(`Need to get ${info.size} of archives.`);
        results.push(`After this operation, ${info.size} of additional disk space will be used.`);
        results.push(`Get:1 http://repo.weblinux.io stable/main amd64 ${pkg} ${info.version} [${info.size}]`);
        results.push(`Fetched ${info.size} in 1s (${info.size}/s)`);
        results.push(`Selecting previously unselected package ${pkg}.`);
        results.push(`Preparing to unpack .../${pkg}_${info.version}_amd64.deb ...`);
        results.push(`Unpacking ${pkg} (${info.version}) ...`);
        results.push(`Setting up ${pkg} (${info.version}) ...`);
        results.push(`Processing triggers for man-db (2.11.2-1) ...`);
        useStore.getState().installPackage(pkg);
      }
      return { output: results.join('\n'), exitCode: 0 };
    }
    case 'remove':
    case 'purge': {
      if (pkgArgs.length === 0) return { output: '', error: 'apt: missing package name', exitCode: 1 };
      const results: string[] = [];
      for (const pkg of pkgArgs) {
        if (!state.installedPackages.includes(pkg)) {
          results.push(`Package '${pkg}' is not installed, so not removed`);
          continue;
        }
        results.push(`Removing ${pkg} ...`);
        results.push(`Processing triggers for man-db (2.11.2-1) ...`);
        useStore.getState().removePackage(pkg);
      }
      return { output: results.join('\n'), exitCode: 0 };
    }
    case 'search': {
      const query = pkgArgs.join(' ').toLowerCase();
      const results: string[] = [];
      for (const [name, info] of Object.entries(availablePackages)) {
        if (name.includes(query) || info.description.toLowerCase().includes(query)) {
          const installed = state.installedPackages.includes(name);
          results.push(`${installed ? 'i' : ' '}${name.padEnd(20)} - ${info.description}`);
        }
      }
      return { output: results.join('\n'), exitCode: 0 };
    }
    case 'list': {
      const results: string[] = [];
      for (const [name, info] of Object.entries(availablePackages)) {
        const installed = state.installedPackages.includes(name);
        results.push(`${installed ? '[installed]' : '           '}${' '.repeat(4)}${name.padEnd(20)}/${info.version}`);
      }
      return { output: results.join('\n'), exitCode: 0 };
    }
    case 'show': {
      const pkg = pkgArgs[0];
      const info = availablePackages[pkg];
      if (!info) return { output: '', error: `E: No packages found`, exitCode: 100 };
      return {
        output: [
          `Package: ${pkg}`,
          `Version: ${info.version}`,
          `Priority: optional`,
          `Section: utils`,
          `Maintainer: WebLinux Team <packages@weblinux.io>`,
          `Installed-Size: ${info.size}`,
          `Homepage: https://packages.weblinux.io/${pkg}`,
          `Description: ${info.description}`,
          ` ${info.description}`,
        ].join('\n'),
        exitCode: 0,
      };
    }
    case 'autoremove': {
      return {
        output: [
          'Reading package lists... Done',
          'Building dependency tree... Done',
          'Reading state information... Done',
          '0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.',
        ].join('\n'),
        exitCode: 0,
      };
    }
    default:
      return { output: '', error: `apt: unknown command "${subcmd}"`, exitCode: 1 };
  }
});

// ===================== USER MANAGEMENT =====================

register('useradd', (cmd, state) => {
  const username = cmd.args[0];
  if (!username) return { output: '', error: 'useradd: missing username', exitCode: 1 };
  const maxUid = Math.max(...state.users.map(u => u.uid), 999);
  useStore.getState().addUser({
    name: username,
    uid: maxUid + 1,
    gid: 1000,
    home: `/home/${username}`,
    shell: '/bin/bash',
  });
  // Create home directory
  const homeDir = `/home/${username}`;
  const parent = findNode(state.filesystem, '/home');
  if (parent && parent.type === 'directory' && parent.children) {
    parent.children[username] = {
      name: username,
      type: 'directory',
      content: '',
      permissions: 'drwxr-xr-x',
      owner: username,
      group: 'users',
      size: 4096,
      modified: Math.floor(Date.now() / 1000),
      children: {},
    };
  }
  return { output: '', exitCode: 0 };
});

register('userdel', (cmd, state) => {
  const username = cmd.args[0];
  if (!username) return { output: '', error: 'userdel: missing username', exitCode: 1 };
  useStore.getState().removeUser(username);
  return { output: '', exitCode: 0 };
});

register('usermod', (cmd, state) => {
  // Simplified - just acknowledge
  return { output: '', exitCode: 0 };
});

register('passwd', (cmd, state) => {
  const username = cmd.args[0] || state.currentUser;
  return { output: `Changing password for ${username}.\nNew password: \nRetype new password: \npasswd: password updated successfully`, exitCode: 0 };
});

register('su', (cmd, state) => {
  const targetUser = cmd.args[0] || 'root';
  const user = state.users.find(u => u.name === targetUser);
  if (!user) return { output: '', error: `su: user ${targetUser} does not exist`, exitCode: 1 };
  useStore.getState().setCurrentUser(targetUser);
  useStore.getState().updateEnvironment('USER', targetUser);
  useStore.getState().updateEnvironment('LOGNAME', targetUser);
  useStore.getState().updateEnvironment('HOME', user.home);
  useStore.getState().updateEnvironment('PS1', targetUser === 'root' ? '\\u@\\h:\\w# ' : '\\u@\\h:\\w\\$ ');
  return { output: '', exitCode: 0 };
});

register('sudo', (cmd, state) => {
  const sudoCmd = cmd.args[0];
  if (!sudoCmd) return { output: '', error: 'sudo: no command specified', exitCode: 1 };
  // Switch to root, execute, switch back
  const origUser = state.currentUser;
  useStore.getState().setCurrentUser('root');
  useStore.getState().updateEnvironment('USER', 'root');
  return { output: '', exitCode: 0 };
});

register('groups', (cmd, state) => {
  const user = cmd.args[0] || state.currentUser;
  const groups = state.groups.filter(g => g.members.includes(user));
  const groupNames = groups.map(g => g.name);
  return { output: `${user} : ${groupNames.join(' ')}`, exitCode: 0 };
});

// ===================== UTILITY COMMANDS =====================

register('tree', (cmd, state) => {
  const target = cmd.args[0] ? resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment)) : state.currentDirectory;
  const node = findNode(state.filesystem, target);
  if (!node) return { output: '', error: `tree: ${cmd.args[0]}: No such file or directory`, exitCode: 1 };
  
  const lines: string[] = [target];
  function printTree(n: FileNode, prefix: string, isLast: boolean) {
    if (n.type !== 'directory' || !n.children) return;
    const entries = Object.values(n.children).sort((a, b) => a.name.localeCompare(b.name));
    entries.forEach((child, i) => {
      const isLastChild = i === entries.length - 1;
      const connector = isLastChild ? '└── ' : '├── ';
      lines.push(`${prefix}${connector}${child.name}`);
      if (child.type === 'directory') {
        const newPrefix = prefix + (isLastChild ? '    ' : '│   ');
        printTree(child, newPrefix, isLastChild);
      }
    });
  }
  printTree(node, '', true);
  
  // Count directories and files
  let dirs = 0, files = 0;
  function count(n: FileNode) {
    if (n.type === 'directory') { dirs++; if (n.children) Object.values(n.children).forEach(count); }
    else files++;
  }
  count(node);
  lines.push('');
  lines.push(`${dirs} directories, ${files} files`);
  
  return { output: lines.join('\n'), exitCode: 0 };
});

register('man', (cmd, _state) => {
  const command = cmd.args[0];
  if (!command) return { output: '', error: 'man: what manual page do you want?', exitCode: 1 };
  const manPages: Record<string, string> = {
    ls: 'LS(1)                          User Commands                          LS(1)\n\nNAME\n       ls - list directory contents\n\nSYNOPSIS\n       ls [OPTION]... [FILE]...\n\nDESCRIPTION\n       List information about the FILEs (the current directory by default).\n\n       -a, --all\n              do not ignore entries starting with .\n\n       -l     use a long listing format\n\n       -h, --human-readable\n              with -l, print sizes in human readable format\n\n       -r, --reverse\n              reverse order while sorting\n\n       -R, --recursive\n              list subdirectories recursively',
    cat: 'CAT(1)                         User Commands                         CAT(1)\n\nNAME\n       cat - concatenate files and print on the standard output\n\nSYNOPSIS\n       cat [OPTION]... [FILE]...\n\nDESCRIPTION\n       Concatenate FILE(s) to standard output.\n\n       -n, --number\n              number all output lines\n\n       -E, --show-ends\n              display $ at end of each line',
    grep: 'GREP(1)                        User Commands                        GREP(1)\n\nNAME\n       grep, egrep, fgrep - print lines that match patterns\n\nSYNOPSIS\n       grep [OPTION...] PATTERNS [FILE...]\n\nDESCRIPTION\n       grep searches for PATTERNS in each FILE.\n\n       -i, --ignore-case\n              ignore case distinctions in patterns and data\n\n       -v, --invert-match\n              select non-matching lines\n\n       -n, --line-number\n              print line number with output lines\n\n       -r, --recursive\n              read all files under each directory, recursively',
  };
  const page = manPages[command];
  if (page) return { output: page, exitCode: 0 };
  return { output: '', error: `man: No manual entry for ${command}`, exitCode: 16 };
});

register('info', (cmd, _state) => {
  const command = cmd.args[0];
  if (!command) return { output: '', error: 'info: missing topic', exitCode: 1 };
  return { output: `Info documentation for ${command} is not available in this virtual environment.\nTry 'man ${command}' instead.`, exitCode: 0 };
});

register('whatis', (cmd, _state) => {
  const command = cmd.args[0];
  if (!command) return { output: '', error: 'whatis: missing topic', exitCode: 1 };
  const descriptions: Record<string, string> = {
    ls: 'ls (1)               - list directory contents',
    cat: 'cat (1)              - concatenate files and print on the standard output',
    grep: 'grep (1)             - print lines that match patterns',
    ps: 'ps (1)               - report a snapshot of the current processes',
    top: 'top (1)              - display Linux processes',
    echo: 'echo (1)             - display a line of text',
    cd: 'cd (1)               - change working directory',
    pwd: 'pwd (1)              - print name of current/working directory',
  };
  const desc = descriptions[command];
  if (desc) return { output: desc, exitCode: 0 };
  return { output: `${command}: nothing appropriate.`, exitCode: 16 };
});

register('alias', (cmd, state) => {
  if (cmd.args.length === 0) {
    // List all aliases
    const lines = Object.entries(state.aliases).map(([k, v]) => `alias ${k}='${v}'`);
    return { output: lines.join('\n'), exitCode: 0 };
  }
  const arg = cmd.args[0];
  const eqIdx = arg.indexOf('=');
  if (eqIdx === -1) {
    // Show specific alias
    const val = state.aliases[arg];
    if (val) return { output: `alias ${arg}='${val}'`, exitCode: 0 };
    return { output: '', error: `bash: alias: ${arg}: not found`, exitCode: 1 };
  }
  const name = arg.substring(0, eqIdx);
  const value = arg.substring(eqIdx + 1).replace(/^['"]|['"]$/g, '');
  useStore.getState().addAlias(name, value);
  return { output: '', exitCode: 0 };
});

register('unalias', (cmd, state) => {
  if (cmd.args.length === 0) return { output: '', error: 'unalias: missing operand', exitCode: 1 };
  const name = cmd.args[0];
  useStore.getState().removeAlias(name);
  return { output: '', exitCode: 0 };
});

register('source', (cmd, state) => {
  if (cmd.args.length === 0) return { output: '', error: 'source: filename argument required', exitCode: 1 };
  const path = resolvePath(state.filesystem, state.currentDirectory, expandVariables(cmd.args[0], state.environment));
  const node = findNode(state.filesystem, path);
  if (!node || node.type !== 'file') return { output: '', error: `source: ${cmd.args[0]}: No such file or directory`, exitCode: 1 };
  return { output: '', exitCode: 0 };
});

register('exit', (_cmd, _state) => {
  return { output: 'logout', error: '', exitCode: 0 };
});

register('reboot', (_cmd, _state) => {
  setTimeout(() => {
    window.location.reload();
  }, 1000);
  return { output: 'Rebooting system...', exitCode: 0 };
});

register('shutdown', (_cmd, _state) => {
  return {
    output: [
      'Shutdown scheduled for now, use \'shutdown -c\' to cancel.',
      '',
      'WebLinux OS is shutting down...',
      '[  OK  ] Stopped target Network.',
      '[  OK  ] Stopped OpenBSD Secure Shell server.',
      '[  OK  ] Stopped Regular background program processing daemon.',
      '[  OK  ] Stopped System Logging Service.',
      '[  OK  ] Stopped OpenBSD Secure Shell server.',
      '[  OK  ] Reached target Power-Off.',
      '[  OK  ] Stopped WebLinux OS.',
      'System halted.',
    ].join('\n'),
    exitCode: 0,
  };
});

register('reset', (_cmd, state) => {
  useStore.getState().resetSystem();
  return { output: 'System reset to factory defaults. Refreshing...', exitCode: 0 };
});

register('help', (_cmd, _state) => {
  const lines = [
    '╔══════════════════════════════════════════════════════════╗',
    '║              WebLinux OS v2.0 - Command Help             ║',
    '╚══════════════════════════════════════════════════════════╝',
    '',
    'FILESYSTEM COMMANDS:',
    '  ls [-lahrtSR] [dir]      List directory contents',
    '  cd [dir]                 Change directory',
    '  pwd                      Print working directory',
    '  cat [-nE] [file]         Display file contents',
    '  echo [-ne] [text]        Print text',
    '  mkdir [-p] [dir]         Create directory',
    '  rmdir [dir]              Remove empty directory',
    '  rm [-rfi] [file]         Remove files',
    '  cp [-r] [src] [dst]      Copy files',
    '  mv [-i] [src] [dst]      Move/rename files',
    '  touch [file]             Create empty file',
    '  ln [-s] [target] [link]  Create links',
    '  find [dir] -name [pat]   Find files',
    '  grep [-invclE] [pat] [f] Search for patterns',
    '  head [-n] [file]         Show first lines',
    '  tail [-n] [file]         Show last lines',
    '  wc [-lwc] [file]         Word count',
    '  sort [-rnk] [file]       Sort lines',
    '  uniq [-cdu] [file]       Filter repeated lines',
    '  diff [file1] [file2]     Compare files',
    '  file [file]              Determine file type',
    '  stat [file]              Show file status',
    '  chmod [mode] [file]      Change permissions',
    '  chown [user] [file]      Change owner',
    '  chgrp [group] [file]     Change group',
    '  du [-hsa] [dir]          Disk usage',
    '  df [-h]                  Free disk space',
    '',
    'SYSTEM COMMANDS:',
    '  ps                       Process status',
    '  top                      Process viewer',
    '  htop                     Enhanced process viewer',
    '  uptime                   System uptime',
    '  whoami                   Current user',
    '  who                      Logged in users',
    '  id [user]                User/group IDs',
    '  uname [-ar]              System information',
    '  hostname                 Show/set hostname',
    '  date [+FORMAT]           Show/set date',
    '  cal [-3y]                Calendar',
    '  clear                    Clear screen',
    '  env                      Environment variables',
    '  export VAR=val           Set environment variable',
    '  which [cmd]              Locate command',
    '  history [-c]             Command history',
    '',
    'TEXT PROCESSING:',
    '  awk [program] [file]     Pattern scanning',
    '  sed [script] [file]      Stream editor',
    '  tr [-ds] [set1] [set2]   Translate characters',
    '  cut [-df] [file]         Cut fields',
    '  tee [-a] [file]          Read/write stdin',
    '  xargs [cmd]              Build commands',
    '  rev [file]               Reverse lines',
    '  tac [file]               Reverse cat',
    '  nl [file]                Number lines',
    '  fold [-w] [file]         Wrap lines',
    '',
    'NETWORK:',
    '  ping [-c] [host]         Test connectivity',
    '  ifconfig                 Network interfaces',
    '  ip [addr/link/route]     IP configuration',
    '  netstat [-tuln]          Network stats',
    '  ss [-tln]                Socket stats',
    '  curl [-ILso] [url]       Transfer URL',
    '  wget [-Oq] [url]         Download file',
    '  host [domain]            DNS lookup',
    '  nslookup [domain]        DNS query',
    '  traceroute [host]        Trace route',
    '',
    'PACKAGE MANAGEMENT:',
    '  apt update               Update package list',
    '  apt upgrade              Upgrade packages',
    '  apt install [pkg]        Install package',
    '  apt remove [pkg]         Remove package',
    '  apt search [query]       Search packages',
    '  apt list                 List packages',
    '  apt show [pkg]           Show package info',
    '  apt autoremove           Remove unused',
    '',
    'USERS:',
    '  useradd [name]           Add user',
    '  userdel [name]           Delete user',
    '  passwd [user]            Change password',
    '  su [user]                Switch user',
    '  sudo [cmd]               Run as root',
    '  groups [user]            Show groups',
    '',
    'UTILITIES:',
    '  tree [dir]               Directory tree',
    '  man [cmd]                Manual page',
    '  alias [name=val]         Create alias',
    '  unalias [name]           Remove alias',
    '  source [file]            Execute script',
    '  exit                     Exit shell',
    '  reboot                   Restart system',
    '  shutdown                 Power off',
    '  reset                    Factory reset',
    '  neofetch                 System info',
    '  cowsay [msg]             ASCII cow',
    '  fortune                  Random quote',
    '  cmatrix                  Matrix rain',
    '  sl                       Steam locomotive',
    '  lolcat [msg]             Rainbow text',
    '  yes [msg]                Repeat text',
    '  seq [n]                  Sequence',
    '  factor [n]               Prime factors',
    '  bc                       Calculator',
    '',
    'KEYBOARD SHORTCUTS:',
    '  Ctrl+L  Clear screen     Tab     Auto-complete',
    '  Ctrl+C  Cancel           Up/Down Command history',
    '  Ctrl+U  Clear line       F1      Toggle sidebar',
    '  Ctrl+A  Line start       F2      Toggle info panel',
    '  Ctrl+E  Line end         F3      Zen mode',
    '',
  ];
  return { output: lines.join('\n'), exitCode: 0 };
});

register('neofetch', (_cmd, _state) => {
  const lines = [
    '         ___  __      __   _          ___  ____ ',
    '        / _ // /___  / /__(_)__  ____/ _ // __ //',
    '       / // / / __ // //_/ / _ // __/ // / /_/ /',
    '      /____/_//___/_//__/_//___/_/ /____//____/ ',
    '    ',
    '    OS: WebLinux OS 2.0 x86_64',
    '    Host: WebLinux Virtual Machine',
    '    Kernel: 2.0.0-virtual',
    '    Uptime: 3 days, 14 hours',
    '    Packages: 14 (apt)',
    '    Shell: bash 5.2.0',
    '    Resolution: 1920x1080',
    '    Terminal: WebLinux Terminal',
    '    CPU: WebLinux Virtual CPU (8) @ 2.40GHz',
    '    Memory: 8192MiB / 16384MiB',
  ];
  return { output: lines.join('\n'), exitCode: 0 };
});


register('cowsay', (cmd, _state) => {
  const message = cmd.args.join(' ') || 'Moo!';
  const bubbleWidth = Math.min(message.length + 2, 40);
  const top = ' ' + '_'.repeat(bubbleWidth);
  const bottom = ' ' + '-'.repeat(bubbleWidth);
  const text = `< ${message.padEnd(bubbleWidth - 2)} >`;
  const cow = [
    top,
    text,
    bottom,
    '        \\   ^__^',
    '         \\  (oo)\\_______',
    '            (__)\\       )\\/\\',
    '                ||----w |',
    '                ||     ||',
  ];
  return { output: cow.join('\n'), exitCode: 0 };
});

register('fortune', (_cmd, _state) => {
  const fortunes = [
    "A journey of a thousand miles begins with a single step.",
    "The early bird catches the worm, but the second mouse gets the cheese.",
    "To be or not to be, that is the question.",
    "I think, therefore I am.",
    "Knowledge is power.",
    "In the middle of difficulty lies opportunity.",
    "The only way to do great work is to love what you do.",
    "Stay hungry, stay foolish.",
    "Simplicity is the ultimate sophistication.",
    "Everything should be made as simple as possible, but not simpler.",
    "Talk is cheap. Show me the code. - Linus Torvalds",
    "Software is like sex: it's better when it's free. - Linus Torvalds",
    "Given enough eyeballs, all bugs are shallow. - Eric S. Raymond",
    "Unix is simple. It just takes a genius to understand its simplicity. - Dennis Ritchie",
    "The best programs are written so that computing machines can perform them quickly and so that human beings can understand them clearly. - Donald Knuth",
  ];
  const fortune = fortunes[Math.floor(Math.random() * fortunes.length)];
  return { output: fortune, exitCode: 0 };
});

register('cmatrix', (_cmd, _state) => {
  return { output: '__CMATRIX__', exitCode: 0 };
});

register('sl', (_cmd, _state) => {
  const train = [
    '      ====        ________                ___________',
    '  _D _|  |_______/        \\__I_I_____===__|_________|',
    '   |(_)---  |   H\\________/ |   |        =|___ ___|   ',
    '   /     |  |   H  |  |     |   |         ||_| |_||    ',
    '  |      |  |   H  |__--------------------| [___] |    ',
    '  | ________|___H__/__|_____/[][]~\\_______|       |   ',
    '  |/ |   |-----------I_____I [][] []  D   |=======|__ ',
    '__/ =| o |=-~~\\  /~~\\  /~~\\  /~~\\ ____Y___________|__ ',
    ' |/-=|___|=    ||    ||    ||    |_____~\\___/        ',
    '  \\_/      \\O=====O=====O=====O_/      \\_/           ',
  ];
  return { output: train.join('\n'), exitCode: 0 };
});

register('lolcat', (cmd, _state) => {
  const text = cmd.args.join(' ') || 'Hello, World!';
  return { output: '__LOLCAT__' + text, exitCode: 0 };
});

register('yes', (cmd, _state) => {
  const text = cmd.args.join(' ') || 'y';
  // Limit to prevent browser hang
  const lines = Array(20).fill(text);
  return { output: lines.join('\n'), exitCode: 0 };
});

register('seq', (cmd, _state) => {
  let start = 1, step = 1, end = 1;
  if (cmd.args.length === 1) end = parseInt(cmd.args[0]);
  else if (cmd.args.length === 2) { start = parseInt(cmd.args[0]); end = parseInt(cmd.args[1]); }
  else if (cmd.args.length >= 3) { start = parseInt(cmd.args[0]); step = parseInt(cmd.args[1]); end = parseInt(cmd.args[2]); }
  const lines: string[] = [];
  for (let i = start; i <= end; i += step) lines.push(String(i));
  return { output: lines.join('\n'), exitCode: 0 };
});

register('factor', (cmd, _state) => {
  const n = parseInt(cmd.args[0]);
  if (isNaN(n) || n < 2) return { output: '', error: 'factor: invalid number', exitCode: 1 };
  let num = n;
  const factors: number[] = [];
  for (let d = 2; d * d <= num; d++) {
    while (num % d === 0) { factors.push(d); num /= d; }
  }
  if (num > 1) factors.push(num);
  return { output: `${n}: ${factors.join(' ')}`, exitCode: 0 };
});

register('bc', (cmd, _state) => {
  if (cmd.args.length === 0) return { output: '', exitCode: 0 };
  try {
    // Simple expression evaluator - use Function for safety
    const expr = cmd.args.join(' ').replace(/[^0-9+\-*/().\s]/g, '');
    // eslint-disable-next-line no-new-func
    const result = new Function('return ' + expr)();
    return { output: String(result), exitCode: 0 };
  } catch {
    return { output: '', error: 'bc: parse error', exitCode: 1 };
  }
});

register('expr', (cmd, _state) => {
  try {
    const expr = cmd.args.join(' ').replace(/[^0-9+\-*/().\s]/g, '');
    // eslint-disable-next-line no-new-func
    const result = new Function('return ' + expr)();
    return { output: String(result), exitCode: 0 };
  } catch {
    return { output: '', error: 'expr: syntax error', exitCode: 2 };
  }
});

// ===================== BUILT-IN ALIASES =====================

// Aliases are expanded before command lookup in the terminal input handler
// The aliases stored in state.aliases are handled there
